export type CategoryType = 'all' | 'mens' | 'casual' | 'running' | 'sale' | 'featured' | 'new-arrivals';

export interface ProductColor {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  name: string;
  category: 'mens' | 'casual' | 'running';
  tag?: 'Bestseller' | 'New Drop' | 'Sale' | 'Trending' | 'Limited Edition';
  price: number;
  salePrice?: number;
  rating: number;
  reviewsCount: number;
  images: string[];
  colors: ProductColor[];
  sizes: number[]; // e.g. [39, 40, 41, 42, 43, 44, 45]
  description: string;
  features: string[];
  material: string;
  soleType: string;
  inStock: boolean;
  isFeatured?: boolean;
  isNewArrival?: boolean;
  isSale?: boolean;
}

export interface CartItem {
  product: Product;
  selectedSize: number;
  selectedColor: ProductColor;
  quantity: number;
}

export interface CustomerReview {
  id: string;
  name: string;
  city: string;
  rating: number;
  date: string;
  productName: string;
  comment: string;
  verified: boolean;
}

export interface CheckoutForm {
  fullName: string;
  phone: string;
  email?: string;
  address: string;
  city: string;
  notes?: string;
}
