import { CustomerReview } from '../types';

export const REVIEWS: CustomerReview[] = [
  {
    id: 'rev-01',
    name: 'Hamza Tariq',
    city: 'Lahore, Punjab',
    rating: 5,
    date: 'March 24, 2026',
    productName: 'Sovereign Italian Leather Oxford',
    comment: 'Ordered through WhatsApp and the team was super responsive! The leather quality blew me away—it matches pairs costing triple the price in malls. The insole comfort is genuinely top tier for long corporate days.',
    verified: true
  },
  {
    id: 'rev-02',
    name: 'Bilal Ahmed',
    city: 'Karachi, Sindh',
    rating: 5,
    date: 'March 18, 2026',
    productName: 'CloudStride Velocity Marathon Runner',
    comment: 'I run 6km every morning at Sea View. The CloudStride sole provides incredible energy return with zero heel strike pain. Delivered in 2 days via Cash on Delivery in Karachi. Highly recommend PrimeStep!',
    verified: true
  },
  {
    id: 'rev-03',
    name: 'Usman Farooq',
    city: 'Islamabad, ICT',
    rating: 5,
    date: 'March 12, 2026',
    productName: 'Urban Court Minimalist Leather Sneaker',
    comment: 'The crisp white leather sneaker is exactly what I was searching for. Minimalist, premium finish with zero loud branding. Fits true to size (EU 43). Will definitely be ordering the Chelsea boot next.',
    verified: true
  },
  {
    id: 'rev-04',
    name: 'Shahid Mehmood',
    city: 'Rawalpindi, Punjab',
    rating: 5,
    date: 'March 02, 2026',
    productName: 'Mayfair Handcrafted Chelsea Boot',
    comment: 'Top craftsmanship! The suede feels rich and plush, and the elastic gusset hugs the ankle nicely without chafing. Ordered directly via the WhatsApp button and received dispatch confirmation in minutes.',
    verified: true
  },
  {
    id: 'rev-05',
    name: 'Kamran Raza',
    city: 'Faisalabad, Punjab',
    rating: 5,
    date: 'February 27, 2026',
    productName: 'AirFlex Ortho-Stride Walking Sneaker',
    comment: 'Bought these for my daily hospital shifts as a doctor. Usually my feet are exhausted by 4 PM, but these AirFlex shoes took away all arch fatigue. The wide toe box is fantastic.',
    verified: true
  },
  {
    id: 'rev-06',
    name: 'Zaryab Ali',
    city: 'Multan, Punjab',
    rating: 5,
    date: 'February 15, 2026',
    productName: 'Monaco Double Monk Strap Classic',
    comment: 'Wore these to my cousin’s wedding and received numerous compliments. The double brass buckles look luxurious. PrimeStep Shoes delivers authentic premium craftsmanship at fair prices.',
    verified: true
  }
];
