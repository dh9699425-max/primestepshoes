import { Product } from '../types';

export const PRODUCTS: Product[] = [
  // MEN'S FORMAL & DRESS SHOES
  {
    id: 'ps-oxford-01',
    name: 'Sovereign Italian Leather Oxford',
    category: 'mens',
    tag: 'Bestseller',
    price: 8999,
    salePrice: 6999,
    rating: 4.9,
    reviewsCount: 142,
    images: [
      'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Burnished Tan', hex: '#8B4513' },
      { name: 'Onyx Black', hex: '#111827' },
      { name: 'Deep Mahogany', hex: '#4A1515' }
    ],
    sizes: [39, 40, 41, 42, 43, 44, 45],
    description: 'Mastercrafted from genuine full-grain calfskin leather with hand-burnished finishing. Features closed lacing, Goodyear-welted construction, and high-density memory latex insole for all-day executive comfort.',
    features: [
      '100% Genuine Full-Grain Calfskin Leather',
      'Hand-stitched closed oxford lacing system',
      'Dual-layer memory foam orthotic footbed',
      'Non-slip textured German rubber outsole',
      'Breathable sheepskin moisture-wicking lining'
    ],
    material: 'Full-Grain Calfskin Leather',
    soleType: 'Reinforced Resin & Rubber Heel',
    inStock: true,
    isFeatured: true,
    isNewArrival: false,
    isSale: true
  },
  {
    id: 'ps-monk-02',
    name: 'Monaco Double Monk Strap Classic',
    category: 'mens',
    tag: 'Limited Edition',
    price: 9499,
    salePrice: 7499,
    rating: 4.8,
    reviewsCount: 88,
    images: [
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Antique Brown', hex: '#5C381E' },
      { name: 'Pitch Black', hex: '#0F172A' }
    ],
    sizes: [40, 41, 42, 43, 44],
    description: 'Sophisticated modern double buckle monk straps with brushed gold hardware. Hand-waxed leather gives an artisanal patina that looks even more distinguished with age.',
    features: [
      'Solid brass double buckle fasteners with elasticated anchors',
      'Ergonomic arch contouring to prevent foot fatigue',
      'Hand-finished edge stained leather welt',
      'Reinforced toe box with sleek tapered silhouette'
    ],
    material: 'Hand-Finished Napa Leather',
    soleType: 'Leather Core with Anti-Skid Pods',
    inStock: true,
    isFeatured: false,
    isNewArrival: true,
    isSale: false
  },
  {
    id: 'ps-chelsea-03',
    name: 'Mayfair Handcrafted Chelsea Boot',
    category: 'mens',
    tag: 'Trending',
    price: 10499,
    salePrice: 8499,
    rating: 4.9,
    reviewsCount: 119,
    images: [
      'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Tobacco Suede', hex: '#704214' },
      { name: 'Midnight Black', hex: '#18181B' }
    ],
    sizes: [39, 40, 41, 42, 43, 44],
    description: 'The definitive silhouette for modern formal and smart-casual dressing. Dual elasticated gussets with heavy-duty pull loops ensure effortless slip-on wear, while water-repellent treated suede guards against sudden splashes.',
    features: [
      'Hydro-shield treated water-resistant suede upper',
      'Elastic stretch side gores with woven nylon heel pulls',
      'Cushioned leather sockliner with heel gel pad',
      'Durable crepe style rubber outsole for silent grip'
    ],
    material: 'Water-Resistant Premium Suede',
    soleType: 'Lightweight Rubber Lug Sole',
    inStock: true,
    isFeatured: true,
    isNewArrival: false,
    isSale: true
  },
  {
    id: 'ps-loafer-04',
    name: 'Royale Horsebit Penny Loafer',
    category: 'mens',
    tag: 'Bestseller',
    price: 7999,
    salePrice: 5999,
    rating: 4.7,
    reviewsCount: 96,
    images: [
      'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Rich Burgundy', hex: '#651C32' },
      { name: 'Espresso Tan', hex: '#44281D' },
      { name: 'Sleek Black', hex: '#0B0F19' }
    ],
    sizes: [39, 40, 41, 42, 43, 44, 45],
    description: 'Effortless slip-on luxury accented with a subtle gold-toned horsebit bar across the vamp. Ideal for wedding wear, boardroom suits, and evening dinners.',
    features: [
      'Polished top-grain aniline leather',
      'Metallic gold-finished horsebit ornament',
      'Seamless interior glove leather lining to prevent blisters',
      'Flexible moccasin construction that molds to your stride'
    ],
    material: 'Top-Grain Aniline Leather',
    soleType: 'Flexible Composite Leather Sole',
    inStock: true,
    isFeatured: false,
    isNewArrival: false,
    isSale: true
  },

  // CASUAL SHOES
  {
    id: 'ps-casual-01',
    name: 'Urban Court Minimalist Leather Sneaker',
    category: 'casual',
    tag: 'Bestseller',
    price: 6499,
    salePrice: 4899,
    rating: 4.9,
    reviewsCount: 230,
    images: [
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Crisp White', hex: '#FFFFFF' },
      { name: 'White & Navy', hex: '#1E293B' },
      { name: 'Cream Stone', hex: '#E2E8F0' }
    ],
    sizes: [39, 40, 41, 42, 43, 44, 45],
    description: 'Clean, architectural, and supremely versatile. Crafted with buttery-soft calf leather, minimal tonal stitching, and a low-profile cupsole that elevates casual jeans, chinos, or relaxed tailoring.',
    features: [
      'Ultra-supple micro-grain leather exterior',
      'High-rebound EVA cushioned footbed with antimicrobial top cover',
      'Durable vulcanized vulcanized rubber cupsole',
      'Waxed cotton flat laces with brushed metal eyelets'
    ],
    material: 'Calf Leather & Breathable Microfiber',
    soleType: 'Heavy-Duty Vulcanized Rubber Cupsole',
    inStock: true,
    isFeatured: true,
    isNewArrival: true,
    isSale: true
  },
  {
    id: 'ps-casual-02',
    name: 'Riviera Suede Venetian Slip-On',
    category: 'casual',
    tag: 'New Drop',
    price: 5999,
    salePrice: 4499,
    rating: 4.8,
    reviewsCount: 74,
    images: [
      'https://images.unsplash.com/photo-1560343090-f0409e92791a?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Sandstone Grey', hex: '#78716C' },
      { name: 'Navy Cobalt', hex: '#1E3A8A' },
      { name: 'Olive Moss', hex: '#3F4F38' }
    ],
    sizes: [40, 41, 42, 43, 44],
    description: 'Light as a feather and relaxed by design. The Riviera slip-on pairs butter-soft brushed suede with an unlined heel counter that allows for slide-in comfort on warm afternoons.',
    features: [
      'Velvety brushed split cow suede',
      'Collapsible heel counter for hybrid slipper/shoe wear',
      'Perforated ergonomic arch cushion for continuous airflow',
      'Siped nautical rubber driving pads for tactile pedal grip'
    ],
    material: 'Italian Split Suede',
    soleType: 'Split Rubber Driving Sole',
    inStock: true,
    isFeatured: true,
    isNewArrival: true,
    isSale: false
  },
  {
    id: 'ps-casual-03',
    name: 'Metro Low Canvas Street Walker',
    category: 'casual',
    tag: 'Sale',
    price: 4999,
    salePrice: 3499,
    rating: 4.7,
    reviewsCount: 165,
    images: [
      'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Coal Black', hex: '#18181B' },
      { name: 'Khaki Beige', hex: '#A89F91' },
      { name: 'Navy Blue', hex: '#0B1F33' }
    ],
    sizes: [39, 40, 41, 42, 43, 44, 45],
    description: 'Everyday durability meets streetwear minimalism. Heavyweight 14oz ring-spun duck canvas keeps feet cool during hot commutes while reinforced double stitch seams stand up to daily use.',
    features: [
      '14oz Double-ply heavy ring-spun cotton canvas',
      'Dual brass side vents for active ventilation',
      'Thickened honeycomb insole absorbs pavement impact',
      'Textured waffle rubber tread for wet surface traction'
    ],
    material: 'Ring-Spun Cotton Duck Canvas',
    soleType: 'High-Density Waffle Rubber',
    inStock: true,
    isFeatured: false,
    isNewArrival: false,
    isSale: true
  },
  {
    id: 'ps-casual-04',
    name: 'AeroStep Retro Suede Jogger Trainer',
    category: 'casual',
    tag: 'Trending',
    price: 6999,
    salePrice: 5299,
    rating: 4.8,
    reviewsCount: 92,
    images: [
      'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Vintage Stone & Navy', hex: '#334155' },
      { name: 'Forest Green & Chalk', hex: '#14532D' }
    ],
    sizes: [40, 41, 42, 43, 44],
    description: 'A 1980s retro-track tribute reimagined with high-tech cushioning. Contrasting suede overlays over ballistic nylon mesh deliver timeless athletic character.',
    features: [
      'Premium suede mudguards with ballistic ripstop underlays',
      'Multi-density dual-color EVA midsole cushion',
      'Padded nylon tongue with woven retro brand badge',
      'Wraparound rubber heel clip for stability'
    ],
    material: 'Suede Overlays & Ballistic Nylon Mesh',
    soleType: 'Dual-Density Lightweight EVA',
    inStock: true,
    isFeatured: false,
    isNewArrival: true,
    isSale: false
  },

  // RUNNING & WALKING SHOES
  {
    id: 'ps-run-01',
    name: 'CloudStride Velocity Marathon Runner',
    category: 'running',
    tag: 'Bestseller',
    price: 8499,
    salePrice: 6299,
    rating: 4.9,
    reviewsCount: 310,
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Ignite Crimson', hex: '#DC2626' },
      { name: 'Stealth Carbon', hex: '#18181B' },
      { name: 'Electric Cyan', hex: '#0284C7' }
    ],
    sizes: [39, 40, 41, 42, 43, 44, 45],
    description: 'Engineered for explosive energy return and ultra-smooth transition mechanics. The nitrogen-infused CloudStride foam absorbs ground shock while the engineered jacquard mesh hugs your foot like a second skin.',
    features: [
      'Nitrogen-infused dynamic supercritical foam midsole',
      'Engineered seamless 3D jacquard mesh with targeted breathability zones',
      'Integrated TPU torsion plate for midfoot stabilization',
      'High-abrasion carbon rubber pods in high-wear heel zones',
      'Anatomical heel collar cradles Achilles tendon without irritation'
    ],
    material: '3D Breathable Jacquard Knit Mesh',
    soleType: 'Supercritical Nitrogen Foam + Carbon Rubber',
    inStock: true,
    isFeatured: true,
    isNewArrival: true,
    isSale: true
  },
  {
    id: 'ps-run-02',
    name: 'AirFlex Ortho-Stride Walking Sneaker',
    category: 'running',
    tag: 'Trending',
    price: 6799,
    salePrice: 4999,
    rating: 4.9,
    reviewsCount: 184,
    images: [
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Heather Grey', hex: '#64748B' },
      { name: 'Deep Midnight', hex: '#0B1F33' },
      { name: 'Pure White', hex: '#F8FAFC' }
    ],
    sizes: [39, 40, 41, 42, 43, 44, 45],
    description: 'Specially designed for long walking shifts, daily exercise, and individuals seeking maximum joint shock absorption. High-arch supportive insole reduces knee and lower-back strain by up to 40%.',
    features: [
      'Doctor-recommended contoured orthotic insole with metatarsal pad',
      'Slip-on sock knit collar with dynamic bungee lace lock',
      'Ultra-wide toe box allowing natural toe splay',
      'Featherweight 240g build (per shoe in EU 42)'
    ],
    material: 'Engineered Stretch AirMesh',
    soleType: 'Shock-Absorbing Air-Pillow Outsole',
    inStock: true,
    isFeatured: true,
    isNewArrival: false,
    isSale: true
  },
  {
    id: 'ps-run-03',
    name: 'TrailMaster All-Terrain Cushioned Walker',
    category: 'running',
    tag: 'New Drop',
    price: 7799,
    salePrice: 5999,
    rating: 4.8,
    reviewsCount: 64,
    images: [
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Tactical Tan & Olive', hex: '#655B46' },
      { name: 'Obsidian Black', hex: '#090D16' }
    ],
    sizes: [40, 41, 42, 43, 44, 45],
    description: 'Built for mixed terrain, park trails, and demanding outdoor adventures. Rugged deep-lug traction grips dirt, gravel, and wet asphalt while internal rock guard shields soles from sharp debris.',
    features: [
      'Reinforced ripstop nylon upper with ballistic welded TPU overlays',
      '4.5mm multi-directional aggressive rubber lugs',
      'Gusseted debris tongue keeps dust and pebbles out',
      'Reinforced rubber toe bumper protects against roots and rocks'
    ],
    material: 'Ballistic Ripstop & Welded TPU',
    soleType: 'All-Terrain Deep-Lug Sticky Rubber',
    inStock: true,
    isFeatured: false,
    isNewArrival: true,
    isSale: false
  },
  {
    id: 'ps-run-04',
    name: 'BreezeKnit Ultralight Slip-On Trainer',
    category: 'running',
    tag: 'Sale',
    price: 5499,
    salePrice: 3899,
    rating: 4.7,
    reviewsCount: 155,
    images: [
      'https://images.unsplash.com/photo-1515955656352-a1fa3ffcd111?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=900&q=80'
    ],
    colors: [
      { name: 'Navy & White', hex: '#1E3A8A' },
      { name: 'All Black', hex: '#000000' }
    ],
    sizes: [39, 40, 41, 42, 43, 44],
    description: 'Slip into instant bliss. The BreezeKnit combines a sock-like single-piece elastic knit upper with a cloud-soft flex outsole that bends naturally with every step.',
    features: [
      'One-piece seamless circular knit construction',
      'Zero-pressure instep with flexible ribbed collar',
      'Washable cushioned insole with moisture vents',
      'Grooved flex sole moves dynamically with foot articulation'
    ],
    material: 'Stretch Circular Knit Fiber',
    soleType: 'Segmented Flex Foam Outsole',
    inStock: true,
    isFeatured: false,
    isNewArrival: false,
    isSale: true
  }
];
