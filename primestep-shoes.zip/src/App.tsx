import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategorySection } from './components/CategorySection';
import { SpecialOffers } from './components/SpecialOffers';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ReviewsSection } from './components/ReviewsSection';
import { SocialSection } from './components/SocialSection';
import { ContactWhatsAppSection } from './components/ContactWhatsAppSection';
import { Footer } from './components/Footer';
import { ProductModal } from './components/ProductModal';
import { ProductCard } from './components/ProductCard';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { SizeGuideModal } from './components/SizeGuideModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { PRODUCTS } from './data/products';
import { CartItem, Product, ProductColor } from './types';
import { 
  SlidersHorizontal, 
  CheckCircle2, 
  Search, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { formatPrice } from './utils/whatsapp';

export default function App() {
  // Products & Collections
  const allProducts = PRODUCTS;

  // State Management
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlistIds, setWishlistIds] = useState<string[]>(['ps-oxford-01', 'ps-run-01']);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSizeFilter, setSelectedSizeFilter] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');

  // Modals & Drawers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  // Toast notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Cart Calculations
  const cartCount = useMemo(() => {
    return cartItems.reduce((acc, it) => acc + it.quantity, 0);
  }, [cartItems]);

  const cartTotal = useMemo(() => {
    return cartItems.reduce((acc, it) => {
      const p = it.product.salePrice || it.product.price;
      return acc + p * it.quantity;
    }, 0);
  }, [cartItems]);

  // Handlers
  const handleAddToCart = (product: Product, size: number, color: ProductColor, qty = 1) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (it) => it.product.id === product.id && it.selectedSize === size && it.selectedColor.name === color.name
      );
      if (existingIndex > -1) {
        const copy = [...prev];
        copy[existingIndex].quantity += qty;
        return copy;
      }
      return [...prev, { product, selectedSize: size, selectedColor: color, quantity: qty }];
    });
    showToast(`Added "${product.name}" (Size EU ${size}, ${color.name}) to bag!`);
  };

  const handleBuyNow = (product: Product, size: number, color: ProductColor, qty = 1) => {
    handleAddToCart(product, size, color, qty);
    setIsProductModalOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleUpdateCartQuantity = (index: number, delta: number) => {
    setCartItems((prev) => {
      const copy = [...prev];
      copy[index].quantity += delta;
      if (copy[index].quantity <= 0) {
        return copy.filter((_, i) => i !== index);
      }
      return copy;
    });
  };

  const handleRemoveCartItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
    showToast('Item removed from shopping bag');
  };

  const handleToggleWishlist = (product: Product) => {
    setWishlistIds((prev) => {
      const exists = prev.includes(product.id);
      if (exists) {
        showToast(`Removed "${product.name}" from wishlist`);
        return prev.filter((id) => id !== product.id);
      } else {
        showToast(`Saved "${product.name}" to wishlist`);
        return [...prev, product.id];
      }
    });
  };

  const handleQuickView = (product: Product) => {
    setSelectedProduct(product);
    setIsProductModalOpen(true);
  };

  // Curated collections
  const featuredProducts = useMemo(() => allProducts.filter((p) => p.isFeatured), [allProducts]);
  const newArrivals = useMemo(() => allProducts.filter((p) => p.isNewArrival), [allProducts]);
  const mensProducts = useMemo(() => allProducts.filter((p) => p.category === 'mens'), [allProducts]);
  const casualProducts = useMemo(() => allProducts.filter((p) => p.category === 'casual'), [allProducts]);
  const runningProducts = useMemo(() => allProducts.filter((p) => p.category === 'running'), [allProducts]);
  const wishlistedProducts = useMemo(() => allProducts.filter((p) => wishlistIds.includes(p.id)), [allProducts, wishlistIds]);

  // Master Filtered & Sorted products for the dedicated #shop section
  const shopCatalogProducts = useMemo(() => {
    let result = [...allProducts];

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.material.toLowerCase().includes(q) ||
          p.colors.some((c) => c.name.toLowerCase().includes(q))
      );
    }

    // Category filter
    if (activeCategory === 'mens') {
      result = result.filter((p) => p.category === 'mens');
    } else if (activeCategory === 'casual') {
      result = result.filter((p) => p.category === 'casual');
    } else if (activeCategory === 'running') {
      result = result.filter((p) => p.category === 'running');
    } else if (activeCategory === 'sale') {
      result = result.filter((p) => p.isSale || (p.salePrice && p.salePrice < p.price));
    } else if (activeCategory === 'new-arrivals') {
      result = result.filter((p) => p.isNewArrival);
    }

    // Size filter
    if (selectedSizeFilter !== null) {
      result = result.filter((p) => p.sizes.includes(selectedSizeFilter));
    }

    // Sort order
    if (sortBy === 'price-asc') {
      result.sort((a, b) => (a.salePrice || a.price) - (b.salePrice || b.price));
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => (b.salePrice || b.price) - (a.salePrice || a.price));
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    }

    return result;
  }, [allProducts, searchQuery, activeCategory, selectedSizeFilter, sortBy]);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 flex items-center gap-2.5 px-4 py-3 bg-[#0B1F33] text-white text-xs font-semibold rounded-2xl shadow-2xl border border-[#D4AF37]/40 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Header with logo, navigation, search, wishlist & cart */}
      <Header
        cartCount={cartCount}
        cartTotal={cartTotal}
        wishlistCount={wishlistIds.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          if (cat !== 'all') {
            scrollToSection('shop');
          }
        }}
        activeCategory={activeCategory}
        searchQuery={searchQuery}
        onSearchChange={(q) => {
          setSearchQuery(q);
          if (q.trim()) {
            scrollToSection('shop');
          }
        }}
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* 3. Hero section with premium banner */}
        <Hero
          onExploreShop={() => scrollToSection('shop')}
          onExploreNewArrivals={() => {
            setActiveCategory('new-arrivals');
            scrollToSection('shop');
          }}
          onExploreSale={() => {
            setActiveCategory('sale');
            scrollToSection('sale');
          }}
        />

        {/* Interactive Master Catalog & Filter Desk */}
        <section id="shop" className="py-12 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37] block">
                  Interactive Catalog
                </span>
                <h2 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#0B1F33]">
                  Explore PrimeStep Footwear
                </h2>
              </div>

              {/* Segmented Category Buttons */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
                {[
                  { id: 'all', label: 'All Shoes' },
                  { id: 'mens', label: "Men's Formal" },
                  { id: 'casual', label: 'Casual Wear' },
                  { id: 'running', label: 'Running & Walking' },
                  { id: 'new-arrivals', label: 'New Drops' },
                  { id: 'sale', label: 'Sale Picks' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveCategory(tab.id)}
                    className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all shrink-0 cursor-pointer ${
                      activeCategory === tab.id
                        ? 'bg-[#0B1F33] text-white shadow-sm'
                        : 'bg-white text-slate-600 hover:bg-slate-200/80 border border-slate-200'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Filter controls row */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-4 text-xs text-slate-600">
              {/* Size quick filter */}
              <div className="flex items-center gap-2">
                <span className="font-medium text-slate-500">Filter by Size:</span>
                <button
                  onClick={() => setSelectedSizeFilter(null)}
                  className={`px-2.5 py-1 rounded-lg border font-mono transition-colors ${
                    selectedSizeFilter === null
                      ? 'bg-[#0B1F33] text-white border-[#0B1F33]'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  All
                </button>
                {[39, 40, 41, 42, 43, 44, 45].map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSizeFilter(selectedSizeFilter === sz ? null : sz)}
                    className={`px-2.5 py-1 rounded-lg border font-mono transition-colors ${
                      selectedSizeFilter === sz
                        ? 'bg-[#0B1F33] text-white border-[#0B1F33]'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>

              {/* Sort by dropdown */}
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
                <span className="font-medium text-slate-500">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-[#0B1F33] font-medium focus:outline-none focus:border-[#0B1F33]"
                >
                  <option value="featured">Featured First</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="rating">Highest Rated</option>
                </select>
              </div>
            </div>

            {/* Results count & reset */}
            <div className="flex items-center justify-between text-xs text-slate-500 pt-3">
              <span>Showing <strong>{shopCatalogProducts.length}</strong> styles</span>
              {(searchQuery || activeCategory !== 'all' || selectedSizeFilter !== null) && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setActiveCategory('all');
                    setSelectedSizeFilter(null);
                  }}
                  className="text-[#0B1F33] hover:underline font-semibold"
                >
                  Reset all filters
                </button>
              )}
            </div>

            {/* Shop Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8 mt-6">
              {shopCatalogProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onBuyNow={handleBuyNow}
                  onQuickView={handleQuickView}
                  onToggleWishlist={handleToggleWishlist}
                  isWishlisted={wishlistIds.includes(product.id)}
                />
              ))}
            </div>

            {shopCatalogProducts.length === 0 && (
              <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 mt-6 space-y-3">
                <Search className="w-10 h-10 text-slate-300 mx-auto" />
                <h3 className="text-base font-semibold text-slate-700">No matching footwear found</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Try adjusting your search terms or reset size filters to browse the complete PrimeStep collection.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setActiveCategory('all');
                    setSelectedSizeFilter(null);
                  }}
                  className="px-4 py-2 bg-[#0B1F33] text-white text-xs font-semibold rounded-xl"
                >
                  View All Shoes
                </button>
              </div>
            )}
          </div>
        </section>

        {/* 4. Featured Products */}
        <CategorySection
          id="featured"
          kicker="Curated Bestsellers"
          title="Featured Footwear"
          description="Handpicked customer favorites renowned for their luxurious textures, immaculate stitching, and daily endurance."
          products={featuredProducts}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onQuickView={handleQuickView}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
          actionLabel="View All Shoes"
          onActionClick={() => scrollToSection('shop')}
        />

        {/* 5. New Arrivals */}
        <CategorySection
          id="new-arrivals"
          kicker="Spring / Summer 2026 Drop"
          title="New Arrivals"
          description="Experience our freshest footwear silhouettes, featuring advanced nitrogen cushioning and hand-burnished patinas."
          products={newArrivals}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onQuickView={handleQuickView}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
          accentBg={true}
          actionLabel="Browse New Drops"
          onActionClick={() => {
            setActiveCategory('new-arrivals');
            scrollToSection('shop');
          }}
        />

        {/* 6. Men's Shoes */}
        <CategorySection
          id="mens"
          kicker="Timeless Executive Elegance"
          title="Men's Formal Shoes"
          description="Italian full-grain calfskin oxfords, distinguished double monk straps, penny loafers, and suede Chelsea boots."
          products={mensProducts}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onQuickView={handleQuickView}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
          actionLabel="Shop Formal Line"
          onActionClick={() => {
            setActiveCategory('mens');
            scrollToSection('shop');
          }}
        />

        {/* 7. Casual Shoes */}
        <CategorySection
          id="casual"
          kicker="Everyday Ease & Street Style"
          title="Casual Shoes & Loafers"
          description="Buttery leather court sneakers, collapsible suede venetian slip-ons, and canvas street walkers for effortless weekend style."
          products={casualProducts}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onQuickView={handleQuickView}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
          accentBg={true}
          actionLabel="Shop Casual Styles"
          onActionClick={() => {
            setActiveCategory('casual');
            scrollToSection('shop');
          }}
        />

        {/* 8. Running & Walking Shoes */}
        <CategorySection
          id="running"
          kicker="Biomechanic Support & Cushion"
          title="Running & Walking Shoes"
          description="Engineered 3D jacquard mesh runners, doctor-recommended orthotic walking sneakers, and all-terrain trail trainers."
          products={runningProducts}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onQuickView={handleQuickView}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
          actionLabel="Shop Athletic Range"
          onActionClick={() => {
            setActiveCategory('running');
            scrollToSection('shop');
          }}
        />

        {/* 9. Special Offers / Sale */}
        <SpecialOffers
          products={allProducts}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onQuickView={handleQuickView}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
        />

        {/* 10. Why Choose PrimeStep Shoes */}
        <WhyChooseUs />

        {/* 11. Customer Reviews */}
        <ReviewsSection />

        {/* 12. Social Media section */}
        <SocialSection />

        {/* 13. Contact / WhatsApp section */}
        <ContactWhatsAppSection />
      </main>

      {/* 14. Professional footer */}
      <Footer
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          scrollToSection('shop');
        }}
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
      />

      {/* Floating WhatsApp Action Button */}
      <FloatingWhatsApp />

      {/* Product Detail / Quick View Modal */}
      <ProductModal
        product={selectedProduct}
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
        onToggleWishlist={handleToggleWishlist}
        isWishlisted={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
      />

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onOpenCheckoutModal={() => setIsCheckoutOpen(true)}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        products={wishlistedProducts}
        onRemoveFromWishlist={(id) => setWishlistIds((prev) => prev.filter((p) => p !== id))}
        onAddToCart={handleAddToCart}
        onQuickView={handleQuickView}
      />

      {/* Cash on Delivery (COD) Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cartItems}
        onOrderSuccess={() => {
          setCartItems([]);
          showToast('Order confirmed successfully!');
        }}
      />

      {/* Footwear Size Guide & Measurement Modal */}
      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
      />
    </div>
  );
}
