import { CartItem, Product, ProductColor } from '../types';

export const WHATSAPP_PHONE_RAW = '03228426461';
export const WHATSAPP_PHONE_INTL = '923228426461';
export const STORE_BLOG_URL = 'https://primestepshoes.blogspot.com/';
export const FACEBOOK_URL = 'https://www.facebook.com/bit.lyPrimeStep';
export const INSTAGRAM_URL = 'https://www.instagram.com/primestepshoes/';
export const PINTEREST_URL = 'https://www.pinterest.com/primestepshoes/';

export function formatPrice(amount: number): string {
  return `Rs. ${amount.toLocaleString('en-PK')}`;
}

/**
 * Builds a direct WhatsApp chat link for a single product order
 */
export function getProductWhatsAppUrl(
  product: Product,
  size?: number,
  color?: ProductColor
): string {
  const chosenSize = size || product.sizes[0];
  const chosenColor = color ? color.name : product.colors[0].name;
  const price = product.salePrice || product.price;

  const message = [
    `*NEW ORDER INQUIRY — PRIMESTEP SHOES* 👟`,
    `----------------------------------------`,
    `*Product:* ${product.name}`,
    `*Price:* ${formatPrice(price)}${product.salePrice ? ` (Discounted from ${formatPrice(product.price)})` : ''}`,
    `*Selected Size:* EU ${chosenSize}`,
    `*Selected Color:* ${chosenColor}`,
    `*Material:* ${product.material}`,
    `----------------------------------------`,
    `Hello PrimeStep team! I would like to place an order for this shoe. Please confirm availability and delivery timeframe to my city.`,
  ].join('\n');

  return `https://wa.me/${WHATSAPP_PHONE_INTL}?text=${encodeURIComponent(message)}`;
}

/**
 * Builds a WhatsApp link for multiple items in the cart
 */
export function getCartWhatsAppUrl(
  items: CartItem[],
  subtotal: number,
  shippingFee: number,
  total: number,
  customerInfo?: { fullName: string; phone: string; city: string; address: string }
): string {
  const lines = [
    `*ONLINE CART ORDER — PRIMESTEP SHOES* 🛍️`,
    `----------------------------------------`,
  ];

  if (customerInfo && customerInfo.fullName) {
    lines.push(
      `*Customer:* ${customerInfo.fullName}`,
      `*Contact Phone:* ${customerInfo.phone}`,
      `*Delivery City:* ${customerInfo.city}`,
      `*Address:* ${customerInfo.address}`,
      `----------------------------------------`
    );
  }

  lines.push(`*ITEMS ORDERED:*`);
  items.forEach((item, idx) => {
    const itemPrice = (item.product.salePrice || item.product.price) * item.quantity;
    lines.push(
      `${idx + 1}. *${item.product.name}*`,
      `   Size: EU ${item.selectedSize} | Color: ${item.selectedColor.name}`,
      `   Qty: ${item.quantity} × ${formatPrice(item.product.salePrice || item.product.price)} = ${formatPrice(itemPrice)}`
    );
  });

  lines.push(
    `----------------------------------------`,
    `*Subtotal:* ${formatPrice(subtotal)}`,
    `*Delivery Charges:* ${shippingFee === 0 ? 'FREE DELIVERY' : formatPrice(shippingFee)}`,
    `*Total Payable:* ${formatPrice(total)} (Cash on Delivery)`,
    `----------------------------------------`,
    `Please confirm my order and share dispatch tracking details. Thank you!`
  );

  return `https://wa.me/${WHATSAPP_PHONE_INTL}?text=${encodeURIComponent(lines.join('\n'))}`;
}

/**
 * Builds a generic customer support inquiry link
 */
export function getSupportWhatsAppUrl(topic?: string): string {
  const msg = topic
    ? `Hello PrimeStep Shoes! I have a question regarding: *${topic}*. Can you assist me?`
    : `Hello PrimeStep Shoes! I would like to inquire about your footwear collection and sizes.`;

  return `https://wa.me/${WHATSAPP_PHONE_INTL}?text=${encodeURIComponent(msg)}`;
}
