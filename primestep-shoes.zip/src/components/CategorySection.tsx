import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Product, ProductColor } from '../types';
import { ProductCard } from './ProductCard';

interface CategorySectionProps {
  id: string;
  kicker: string;
  title: string;
  description: string;
  products: Product[];
  onAddToCart: (product: Product, size: number, color: ProductColor) => void;
  onBuyNow: (product: Product, size: number, color: ProductColor) => void;
  onQuickView: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: string[];
  actionLabel?: string;
  onActionClick?: () => void;
  accentBg?: boolean;
}

export const CategorySection: React.FC<CategorySectionProps> = ({
  id,
  kicker,
  title,
  description,
  products,
  onAddToCart,
  onBuyNow,
  onQuickView,
  onToggleWishlist,
  wishlistIds,
  actionLabel,
  onActionClick,
  accentBg = false,
}) => {
  if (products.length === 0) return null;

  return (
    <section id={id} className={`py-14 sm:py-20 ${accentBg ? 'bg-slate-50/70 border-y border-slate-200/60' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10 sm:mb-12">
          <div className="max-w-2xl space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
              <span className="text-xs uppercase tracking-widest font-bold text-[#D4AF37]">
                {kicker}
              </span>
            </div>
            <h2 className="font-serif-luxury text-2xl sm:text-3xl lg:text-4xl font-bold text-[#0B1F33] tracking-tight">
              {title}
            </h2>
            <p className="text-sm text-slate-500 leading-relaxed">
              {description}
            </p>
          </div>

          {actionLabel && onActionClick && (
            <button
              type="button"
              onClick={onActionClick}
              className="inline-flex items-center gap-2 text-xs uppercase tracking-wider font-bold text-[#0B1F33] hover:text-[#D4AF37] pb-1 border-b border-[#0B1F33] hover:border-[#D4AF37] transition-all cursor-pointer self-start md:self-end"
            >
              <span>{actionLabel}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
              onBuyNow={onBuyNow}
              onQuickView={onQuickView}
              onToggleWishlist={onToggleWishlist}
              isWishlisted={wishlistIds.includes(product.id)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
