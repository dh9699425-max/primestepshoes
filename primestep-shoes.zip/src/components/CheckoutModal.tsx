import React, { useState } from 'react';
import { X, CheckCircle2, MessageCircle, Truck, ShieldCheck, MapPin, Phone, User, Home, ArrowRight } from 'lucide-react';
import { CartItem, CheckoutForm } from '../types';
import { formatPrice, getCartWhatsAppUrl, WHATSAPP_PHONE_RAW } from '../utils/whatsapp';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onOrderSuccess: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  onOrderSuccess,
}) => {
  const [formData, setFormData] = useState<CheckoutForm>({
    fullName: '',
    phone: '',
    email: '',
    address: '',
    city: 'Lahore',
    notes: '',
  });

  const [orderPlaced, setOrderPlaced] = useState<boolean>(false);
  const [orderId, setOrderId] = useState<string>('');

  if (!isOpen) return null;

  const rawSubtotal = items.reduce((sum, item) => {
    const price = item.product.salePrice || item.product.price;
    return sum + price * item.quantity;
  }, 0);
  const shippingFee = rawSubtotal >= 5000 ? 0 : 250;
  const total = rawSubtotal + shippingFee;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.phone || !formData.address) {
      alert('Please fill in your name, contact phone, and delivery address.');
      return;
    }

    const generatedId = `PS-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderId(generatedId);
    setOrderPlaced(true);
    onOrderSuccess();
  };

  const handleSendToWhatsApp = () => {
    const url = getCartWhatsAppUrl(items, rawSubtotal, shippingFee, total, {
      fullName: formData.fullName,
      phone: formData.phone,
      city: formData.city,
      address: formData.address,
    });
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden border border-slate-200 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#0B1F33] text-white">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-serif-luxury text-lg tracking-wide">
              {orderPlaced ? 'Order Confirmation' : 'Cash on Delivery (COD) Checkout'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {orderPlaced ? (
            /* Success State */
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-xs uppercase font-mono tracking-widest text-[#D4AF37] font-semibold">
                  Order #{orderId}
                </span>
                <h3 className="font-serif-luxury text-2xl font-bold text-[#0B1F33] mt-1">
                  Thank You, {formData.fullName}!
                </h3>
                <p className="text-sm text-slate-600 max-w-md mx-auto mt-2">
                  Your footwear order has been successfully placed. Our dispatch manager will verify your order and arrange express shipping to <strong>{formData.city}</strong>.
                </p>
              </div>

              {/* Order summary box */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left max-w-md mx-auto space-y-2 text-xs">
                <div className="flex justify-between font-semibold text-[#0B1F33]">
                  <span>Total Payable on Delivery:</span>
                  <span className="font-mono text-sm">{formatPrice(total)}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Shipping Address:</span>
                  <span className="text-slate-800 text-right">{formData.address}, {formData.city}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Contact Phone:</span>
                  <span className="text-slate-800 font-mono">{formData.phone}</span>
                </div>
              </div>

              {/* Instant WhatsApp verification CTA */}
              <div className="max-w-md mx-auto pt-2 space-y-3">
                <button
                  type="button"
                  onClick={handleSendToWhatsApp}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl shadow-md transition-all cursor-pointer text-sm"
                >
                  <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                  <span>Send Order to WhatsApp ({WHATSAPP_PHONE_RAW})</span>
                </button>
                <p className="text-[11px] text-slate-400">
                  Speed up delivery by sending this order directly to our WhatsApp representative.
                </p>
              </div>
            </div>
          ) : (
            /* Checkout Form */
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-3 text-xs text-amber-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>
                  <strong>Cash on Delivery (COD)</strong>: Pay with cash when the courier delivers your package to your doorstep.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Muhammad Ali"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#0B1F33]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    WhatsApp / Phone Number *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 0322 8426461"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#0B1F33]"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Delivery Street Address *
                  </label>
                  <div className="relative">
                    <Home className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="House / Flat #, Street, Area"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#0B1F33]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    City *
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <select
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#0B1F33]"
                    >
                      <option value="Lahore">Lahore</option>
                      <option value="Karachi">Karachi</option>
                      <option value="Islamabad">Islamabad</option>
                      <option value="Rawalpindi">Rawalpindi</option>
                      <option value="Faisalabad">Faisalabad</option>
                      <option value="Multan">Multan</option>
                      <option value="Peshawar">Peshawar</option>
                      <option value="Sialkot">Sialkot</option>
                      <option value="Gujranwala">Gujranwala</option>
                      <option value="Quetta">Quetta</option>
                      <option value="Other City">Other City (Nationwide)</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Order Notes (Optional)
                </label>
                <input
                  type="text"
                  placeholder="Special landmark, preferred delivery timing, etc."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#0B1F33]"
                />
              </div>

              {/* Order Summary Line */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Items ({items.length}):</span>
                  <span className="font-mono text-slate-800 font-medium">{formatPrice(rawSubtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Express Delivery:</span>
                  <span className="font-mono text-slate-800">
                    {shippingFee === 0 ? <span className="text-emerald-700 font-semibold">FREE</span> : formatPrice(shippingFee)}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-bold text-[#0B1F33] pt-1.5 border-t border-slate-200">
                  <span>Payable Upon Delivery:</span>
                  <span className="font-mono text-base">{formatPrice(total)}</span>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-[#0B1F33] hover:bg-[#132c48] text-white text-sm font-semibold rounded-xl shadow-md transition-all cursor-pointer"
                >
                  <span>Confirm Cash on Delivery Order</span>
                  <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                </button>

                <button
                  type="button"
                  onClick={handleSendToWhatsApp}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-all cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                  <span>Prefer to Order on WhatsApp? Click Here</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
