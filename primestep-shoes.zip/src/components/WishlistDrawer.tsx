import React from 'react';
import { X, Heart, ShoppingBag, MessageCircle, ArrowRight, Trash2 } from 'lucide-react';
import { Product, ProductColor } from '../types';
import { formatPrice, getProductWhatsAppUrl, WHATSAPP_PHONE_RAW } from '../utils/whatsapp';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onRemoveFromWishlist: (productId: string) => void;
  onAddToCart: (product: Product, size: number, color: ProductColor) => void;
  onQuickView: (product: Product) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  products,
  onRemoveFromWishlist,
  onAddToCart,
  onQuickView,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between border-l border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-[#0B1F33] text-white">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-500 fill-red-500" />
            <h3 className="font-serif-luxury text-lg tracking-wide">Saved Wishlist</h3>
            <span className="text-xs bg-[#D4AF37] text-[#0B1F33] font-bold px-2 py-0.5 rounded-full font-mono">
              {products.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close wishlist"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {products.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12 text-slate-400">
              <Heart className="w-16 h-16 stroke-[1.2] mb-3 text-slate-300" />
              <h4 className="text-base font-semibold text-slate-700">No saved shoes yet</h4>
              <p className="text-xs text-slate-500 max-w-xs mt-1">
                Click the heart icon on any shoe to save it to your wishlist for later.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-6 px-6 py-2.5 bg-[#0B1F33] text-white text-xs font-semibold uppercase tracking-wider rounded-xl hover:bg-[#132c48] transition-colors"
              >
                Browse Shoes
              </button>
            </div>
          ) : (
            products.map((product) => (
              <div
                key={product.id}
                className="flex gap-4 p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-50 transition-colors"
              >
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-20 h-20 object-cover rounded-lg shrink-0 border border-slate-200"
                />

                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-1">
                      <h4 
                        onClick={() => {
                          onClose();
                          onQuickView(product);
                        }}
                        className="text-xs sm:text-sm font-semibold text-[#0B1F33] truncate cursor-pointer hover:underline"
                      >
                        {product.name}
                      </h4>
                      <button
                        type="button"
                        onClick={() => onRemoveFromWishlist(product.id)}
                        className="text-slate-400 hover:text-red-600 p-1 transition-colors"
                        aria-label="Remove from wishlist"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-baseline gap-2 mt-1">
                      <span className="font-mono text-sm font-bold text-[#0B1F33]">
                        {formatPrice(product.salePrice || product.price)}
                      </span>
                      {product.salePrice && (
                        <span className="font-mono text-xs text-slate-400 line-through">
                          {formatPrice(product.price)}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-200">
                    <button
                      type="button"
                      onClick={() => {
                        onAddToCart(product, product.sizes[0], product.colors[0]);
                      }}
                      className="flex-1 py-1.5 px-2 bg-[#0B1F33] hover:bg-[#132c48] text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <ShoppingBag className="w-3 h-3" />
                      <span>Add to Bag</span>
                    </button>

                    <a
                      href={getProductWhatsAppUrl(product)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors"
                      title="Order on WhatsApp"
                    >
                      <MessageCircle className="w-4 h-4 fill-white" />
                    </a>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {products.length > 0 && (
          <div className="p-4 border-t border-slate-200 bg-slate-50 text-center">
            <span className="text-xs text-slate-500">
              WhatsApp Order Line: <strong className="text-[#0B1F33] font-mono">{WHATSAPP_PHONE_RAW}</strong>
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
