import React from 'react';
import { ExternalLink, Instagram, Facebook, Heart } from 'lucide-react';
import { FACEBOOK_URL, INSTAGRAM_URL, PINTEREST_URL, STORE_BLOG_URL } from '../utils/whatsapp';

export const SocialSection: React.FC = () => {
  const lookbookPosts = [
    {
      image: 'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=600&q=80',
      caption: 'Executive boardroom styling with the Sovereign Italian Oxford. Pure perfection.',
      likes: '482',
      tag: '@primestepshoes'
    },
    {
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=600&q=80',
      caption: 'Sunday brunch simplicity in our Urban Court minimal leather sneakers.',
      likes: '395',
      tag: '#StepIntoStyle'
    },
    {
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80',
      caption: 'Morning run pacing in the CloudStride Velocity. Cushion that keeps you flying.',
      likes: '620',
      tag: '#PrimeStepRun'
    },
    {
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&w=600&q=80',
      caption: 'Mayfair Chelsea Boots paired with tailored flannel trousers.',
      likes: '512',
      tag: '@primestepshoes'
    }
  ];

  return (
    <section id="social" className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
            <span className="text-xs uppercase tracking-widest font-bold text-[#D4AF37]">
              Community & Style
            </span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-[#0B1F33] tracking-tight">
            Follow PrimeStep Shoes
          </h2>
          <p className="text-sm text-slate-500 leading-relaxed">
            Tag <strong>#StepIntoStyle</strong> on Instagram and Facebook to be featured in our monthly customer showcase.
          </p>

          {/* Direct Social Media Badges */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
            {/* Instagram */}
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 via-pink-600 to-amber-500 text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-xs transition-opacity"
            >
              <Instagram className="w-4 h-4" />
              <span>@primestepshoes</span>
              <ExternalLink className="w-3 h-3 ml-0.5 opacity-80" />
            </a>

            {/* Facebook */}
            <a
              href={FACEBOOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#1877F2] text-white rounded-xl text-xs font-semibold hover:bg-[#166fe5] shadow-xs transition-colors"
            >
              <Facebook className="w-4 h-4" />
              <span>Facebook / bit.lyPrimeStep</span>
              <ExternalLink className="w-3 h-3 ml-0.5 opacity-80" />
            </a>

            {/* Pinterest */}
            <a
              href={PINTEREST_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#E60023] text-white rounded-xl text-xs font-semibold hover:bg-[#cc0020] shadow-xs transition-colors"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345-.09.375-.291 1.199-.332 1.357-.053.211-.174.256-.402.155-1.499-.696-2.435-2.88-2.435-4.634 0-3.774 2.743-7.239 7.904-7.239 4.151 0 7.378 2.958 7.378 6.91 0 4.123-2.599 7.441-6.207 7.441-1.212 0-2.352-.63-2.743-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146 1.124.347 2.317.535 3.554.535 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/>
              </svg>
              <span>Pinterest / primestepshoes</span>
              <ExternalLink className="w-3 h-3 ml-0.5 opacity-80" />
            </a>

            {/* Official Website */}
            <a
              href={STORE_BLOG_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#0B1F33] text-white rounded-xl text-xs font-semibold hover:bg-[#132c48] shadow-xs transition-colors"
            >
              <span>primestepshoes.blogspot.com</span>
              <ExternalLink className="w-3 h-3 ml-0.5 text-[#D4AF37]" />
            </a>
          </div>
        </div>

        {/* Lookbook Feed Tiles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {lookbookPosts.map((post, index) => (
            <a
              key={index}
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative rounded-2xl overflow-hidden aspect-square border border-slate-200/80 shadow-xs hover:shadow-xl transition-all"
            >
              <img
                src={post.image}
                alt={post.caption}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />

              {/* Scrim Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-between text-white">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#D4AF37]">{post.tag}</span>
                  <div className="flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 fill-red-500 text-red-500" />
                    <span>{post.likes}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-xs line-clamp-2 leading-relaxed text-slate-200">
                    {post.caption}
                  </p>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-1 pt-1">
                    <span>View on Instagram</span>
                    <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};
