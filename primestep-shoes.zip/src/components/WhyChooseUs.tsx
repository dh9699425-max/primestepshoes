import React from 'react';
import { Award, Feather, Truck, RotateCcw, ShieldCheck, HeartHandshake } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const pillars = [
    {
      icon: Award,
      title: 'Artisanal Craftsmanship',
      description: 'Every shoe is crafted by seasoned cobblers using full-grain leathers, robust welt stitching, and precision-cut panels that retain their shape over years of use.',
      badge: 'Uncompromising Quality'
    },
    {
      icon: Feather,
      title: 'Ergonomic All-Day Cushioning',
      description: 'Our proprietary anatomical footbeds feature dual-density memory foam and targeted arch contours that relieve heel pressure during long hours on your feet.',
      badge: 'Orthotic Comfort'
    },
    {
      icon: Truck,
      title: 'Nationwide Cash on Delivery (COD)',
      description: 'Order with complete confidence. Inspect your package at your doorstep and pay in cash to the delivery rider anywhere across Pakistan.',
      badge: '100% Safe Ordering'
    },
    {
      icon: RotateCcw,
      title: '7-Day Hassle-Free Size Exchange',
      description: 'Shoes don’t fit quite right? We arrange a fast, friendly doorstep size replacement within 7 days. Your perfect fit is our priority.',
      badge: 'Guaranteed Fit'
    },
  ];

  return (
    <section id="why-us" className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
            <span className="text-xs uppercase tracking-widest font-bold text-[#D4AF37]">
              The PrimeStep Distinction
            </span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-[#0B1F33] tracking-tight">
            Why Choose PrimeStep Shoes?
          </h2>
          <p className="text-sm text-slate-500 leading-relaxed">
            We bridge the gap between luxury footwear aesthetics and everyday comfort. No shortcuts, no false markups—just honest craftsmanship.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {pillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <div
                key={idx}
                className="group relative p-6 sm:p-7 rounded-2xl bg-slate-50/70 border border-slate-200/80 hover:border-[#0B1F33]/30 hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#0B1F33] text-[#D4AF37] flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-xs">
                    <Icon className="w-6 h-6 stroke-[1.5]" />
                  </div>

                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#D4AF37] block mb-1">
                    {pillar.badge}
                  </span>

                  <h3 className="font-serif-luxury text-lg font-bold text-[#0B1F33] mb-2.5">
                    {pillar.title}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-200/60 flex items-center gap-1.5 text-[11px] font-semibold text-[#0B1F33]">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>PrimeStep Quality Promise</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
