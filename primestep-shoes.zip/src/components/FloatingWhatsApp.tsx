import React, { useState } from 'react';
import { MessageCircle, X, Send, Sparkles } from 'lucide-react';
import { WHATSAPP_PHONE_RAW, getSupportWhatsAppUrl, WHATSAPP_PHONE_INTL } from '../utils/whatsapp';

export const FloatingWhatsApp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [quickText, setQuickText] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    const text = quickText.trim() || 'Hello PrimeStep Shoes, I need assistance with an order.';
    const url = `https://wa.me/${WHATSAPP_PHONE_INTL}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
    setIsOpen(false);
    setQuickText('');
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {/* Popover Bubble */}
      {isOpen && (
        <div className="mb-3 w-72 sm:w-80 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-fadeIn">
          {/* Card Header */}
          <div className="bg-[#0B1F33] p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-emerald-500 flex items-center justify-center text-white">
                <MessageCircle className="w-5 h-5 fill-white" />
              </div>
              <div>
                <h4 className="text-xs font-bold leading-tight">PrimeStep Shoes Care</h4>
                <div className="flex items-center gap-1 text-[10px] text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Online · Typically replies in seconds</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-white/10"
              aria-label="Close chat bubble"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Card Body */}
          <div className="p-4 bg-slate-50 space-y-3">
            <div className="bg-white p-3 rounded-xl border border-slate-200 text-xs text-slate-700 shadow-xs">
              <p className="leading-relaxed">
                👋 Assalam-o-Alaikum! Welcome to <strong>PrimeStep Shoes</strong>. How can we help you choose your ideal pair today?
              </p>
              <span className="text-[10px] text-slate-400 block mt-1">Official WhatsApp: {WHATSAPP_PHONE_RAW}</span>
            </div>

            <form onSubmit={handleSend} className="space-y-2">
              <input
                type="text"
                placeholder="Type your question or shoe size..."
                value={quickText}
                onChange={(e) => setQuickText(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-600"
              />
              <button
                type="submit"
                className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Start WhatsApp Chat</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-2.5 p-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer"
        aria-label="Chat on WhatsApp"
      >
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#D4AF37] rounded-full border-2 border-white animate-pulse" />
        <MessageCircle className="w-6 h-6 fill-white" />
        <span className="hidden sm:inline font-semibold text-xs pr-1">
          WhatsApp Order ({WHATSAPP_PHONE_RAW})
        </span>
      </button>
    </div>
  );
};
