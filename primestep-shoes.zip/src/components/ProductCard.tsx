import React, { useState } from 'react';
import { ShoppingBag, Eye, Heart, MessageCircle, ArrowRight, Star, Sparkles } from 'lucide-react';
import { Product, ProductColor } from '../types';
import { formatPrice, getProductWhatsAppUrl } from '../utils/whatsapp';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, size: number, color: ProductColor) => void;
  onBuyNow: (product: Product, size: number, color: ProductColor) => void;
  onQuickView: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
  onOpenSizeGuide?: () => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onBuyNow,
  onQuickView,
  onToggleWishlist,
  isWishlisted,
}) => {
  const [selectedSize, setSelectedSize] = useState<number>(product.sizes[0] || 42);
  const [selectedColor, setSelectedColor] = useState<ProductColor>(product.colors[0]);
  const [imageLoaded, setImageLoaded] = useState<boolean>(true);
  const [currentImageIndex, setCurrentImageIndex] = useState<number>(0);

  const discountPercent = product.salePrice
    ? Math.round(((product.price - product.salePrice) / product.price) * 100)
    : 0;

  const handleWhatsAppClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = getProductWhatsAppUrl(product, selectedSize, selectedColor);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, selectedSize, selectedColor);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    onBuyNow(product, selectedSize, selectedColor);
  };

  return (
    <div 
      className="group relative flex flex-col bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-xl transition-all duration-300 overflow-hidden"
      onClick={() => onQuickView(product)}
    >
      {/* Visual Area */}
      <div className="relative aspect-4/3 w-full bg-slate-100/80 overflow-hidden cursor-pointer">
        {/* Badges */}
        <div className="absolute top-3 left-3 z-10 flex flex-col gap-1 items-start">
          {discountPercent > 0 && (
            <span className="px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider bg-red-600 text-white rounded-md shadow-xs">
              SAVE {discountPercent}%
            </span>
          )}
          {product.tag && (
            <span className="px-2.5 py-1 text-[11px] font-semibold tracking-wider bg-[#0B1F33] text-[#D4AF37] rounded-md shadow-xs flex items-center gap-1">
              {product.tag === 'New Drop' && <Sparkles className="w-3 h-3 text-[#D4AF37]" />}
              {product.tag}
            </span>
          )}
        </div>

        {/* Action icons top right */}
        <div className="absolute top-3 right-3 z-10 flex flex-col gap-2">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(product);
            }}
            aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
            className={`p-2 rounded-full backdrop-blur-md transition-all ${
              isWishlisted
                ? 'bg-red-50 text-red-600 shadow-sm'
                : 'bg-white/80 text-slate-600 hover:text-red-600 hover:bg-white shadow-xs'
            }`}
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onQuickView(product);
            }}
            aria-label="Quick preview product"
            className="p-2 rounded-full bg-white/80 backdrop-blur-md text-slate-600 hover:text-[#0B1F33] hover:bg-white transition-all shadow-xs"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>

        {/* Image with fallback */}
        {imageLoaded ? (
          <img
            src={product.images[currentImageIndex] || product.images[0]}
            alt={product.name}
            referrerPolicy="no-referrer"
            onError={() => setImageLoaded(false)}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 text-slate-400 p-4">
            <ShoppingBag className="w-12 h-12 stroke-[1.2] mb-2 text-[#0B1F33]/40" />
            <span className="text-xs font-medium text-slate-500">{product.name}</span>
          </div>
        )}

        {/* Subtle quick image switcher if multiple exist */}
        {product.images.length > 1 && (
          <div 
            className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-2 py-1 rounded-full bg-black/30 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={(e) => e.stopPropagation()}
          >
            {product.images.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentImageIndex(idx)}
                aria-label={`Show view ${idx + 1}`}
                className={`w-1.5 h-1.5 rounded-full transition-all ${
                  currentImageIndex === idx ? 'bg-white w-3' : 'bg-white/60'
                }`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Content Area */}
      <div className="p-4 sm:p-5 flex flex-col flex-1 justify-between gap-3">
        {/* Category & Rating */}
        <div>
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
            <span className="uppercase tracking-wider font-semibold text-[#D4AF37] text-[11px]">
              {product.category === 'mens' ? "Men's Formal" : product.category === 'casual' ? 'Casual Wear' : 'Athletic & Running'}
            </span>
            <div className="flex items-center gap-1 text-slate-700">
              <Star className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
              <span className="font-semibold text-xs">{product.rating}</span>
              <span className="text-slate-400 text-[11px]">({product.reviewsCount})</span>
            </div>
          </div>

          {/* Product Title */}
          <h3 className="font-medium text-[#0B1F33] text-base line-clamp-1 group-hover:text-[#132c48] transition-colors">
            {product.name}
          </h3>

          {/* Short Description */}
          <p className="text-xs text-slate-500 line-clamp-2 mt-1 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Color Swatches */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            <span className="text-[11px] text-slate-500 mr-0.5">Color:</span>
            {product.colors.map((c) => (
              <button
                key={c.name}
                type="button"
                title={c.name}
                onClick={() => setSelectedColor(c)}
                className={`w-4 h-4 rounded-full border transition-all ${
                  selectedColor.name === c.name
                    ? 'ring-2 ring-[#0B1F33] ring-offset-1 scale-110'
                    : 'border-slate-300 hover:scale-105'
                }`}
                style={{ backgroundColor: c.hex }}
              />
            ))}
            <span className="text-[11px] font-medium text-slate-700 ml-1 truncate max-w-[80px]">
              {selectedColor.name}
            </span>
          </div>

          <span className="text-[11px] text-emerald-700 font-medium">In Stock</span>
        </div>

        {/* Size Selection Chips */}
        <div className="space-y-1.5 pt-1" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>Size (EU):</span>
            <span className="text-slate-700 font-medium">Selected: EU {selectedSize}</span>
          </div>
          <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
            {product.sizes.map((sz) => (
              <button
                key={sz}
                type="button"
                onClick={() => setSelectedSize(sz)}
                className={`px-2 py-1 text-xs rounded-md font-mono font-medium transition-colors ${
                  selectedSize === sz
                    ? 'bg-[#0B1F33] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>
        </div>

        {/* Price Row */}
        <div className="flex items-baseline justify-between pt-2 border-t border-slate-100">
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-[#0B1F33] tracking-tight font-mono">
              {formatPrice(product.salePrice || product.price)}
            </span>
            {product.salePrice && (
              <span className="text-xs text-slate-400 line-through font-mono">
                {formatPrice(product.price)}
              </span>
            )}
          </div>
          <span className="text-[10px] text-slate-400 uppercase tracking-wider">
            Cash on Delivery
          </span>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1" onClick={(e) => e.stopPropagation()}>
          {/* Order on WhatsApp button (Mandatory highlighted feature) */}
          <button
            type="button"
            onClick={handleWhatsAppClick}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-all shadow-xs hover:shadow-md cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-white text-emerald-600" />
            <span>Order on WhatsApp (03228426461)</span>
          </button>

          {/* Cart & Buy Now Action Grid */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleAddToCart}
              className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-medium text-[#0B1F33] bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Add to Cart</span>
            </button>

            <button
              type="button"
              onClick={handleBuyNow}
              className="flex items-center justify-center gap-1 py-2 px-3 text-xs font-semibold text-white bg-[#0B1F33] hover:bg-[#132c48] rounded-xl transition-colors cursor-pointer"
            >
              <span>Buy Now</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
