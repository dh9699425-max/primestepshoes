import React from 'react';
import { X, Ruler, CheckCircle2 } from 'lucide-react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const sizeTable = [
    { eu: 39, us: '6.5', uk: '6.0', cm: '24.5', inch: '9.6' },
    { eu: 40, us: '7.5', uk: '6.5', cm: '25.0', inch: '9.8' },
    { eu: 41, us: '8.0', uk: '7.5', cm: '26.0', inch: '10.2' },
    { eu: 42, us: '9.0', uk: '8.5', cm: '26.5', inch: '10.4' },
    { eu: 43, us: '10.0', uk: '9.5', cm: '27.5', inch: '10.8' },
    { eu: 44, us: '11.0', uk: '10.5', cm: '28.0', inch: '11.0' },
    { eu: 45, us: '12.0', uk: '11.5', cm: '29.0', inch: '11.4' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-100 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#0B1F33] text-white">
          <div className="flex items-center gap-2">
            <Ruler className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-serif-luxury text-lg tracking-wide">PrimeStep Shoes — Footwear Sizing Guide</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close size guide"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          <p className="text-sm text-slate-600 leading-relaxed">
            All PrimeStep footwear follows standard international sizing. For dress shoes and boots, we recommend ordering your exact dress shoe size. For athletic runners, if you have wider feet, we advise going half a size up.
          </p>

          {/* Sizing Table */}
          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-100/80 text-[#0B1F33] font-semibold border-b border-slate-200 text-xs uppercase tracking-wider">
                  <th className="py-3 px-4">EU Size</th>
                  <th className="py-3 px-4">US Size</th>
                  <th className="py-3 px-4">UK Size</th>
                  <th className="py-3 px-4">Foot Length (cm)</th>
                  <th className="py-3 px-4">Inches</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-xs sm:text-sm">
                {sizeTable.map((row) => (
                  <tr key={row.eu} className="hover:bg-amber-50/40 transition-colors">
                    <td className="py-2.5 px-4 font-bold text-[#0B1F33]">EU {row.eu}</td>
                    <td className="py-2.5 px-4 text-slate-700">{row.us}</td>
                    <td className="py-2.5 px-4 text-slate-700">{row.uk}</td>
                    <td className="py-2.5 px-4 text-slate-700">{row.cm} cm</td>
                    <td className="py-2.5 px-4 text-slate-500">{row.inch}"</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* How to Measure */}
          <div className="bg-slate-50 p-5 rounded-xl border border-slate-200/80">
            <h4 className="font-semibold text-[#0B1F33] text-sm mb-3 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
              How to Measure Your Foot Length Accurately
            </h4>
            <ol className="text-xs text-slate-600 space-y-2 list-decimal list-inside">
              <li>Place a clean sheet of A4 paper on a hard floor against a flat wall.</li>
              <li>Stand on the paper with your heel firmly touching the wall while wearing your usual socks.</li>
              <li>Mark the furthest point of your longest toe using a pencil held perpendicular to the paper.</li>
              <li>Measure the distance from the edge of the paper (heel) to the mark in centimeters.</li>
              <li>Compare the measurement with our chart above to select your ideal EU shoe size.</li>
            </ol>
          </div>

          {/* Assurance */}
          <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Unsure about your exact fit?</span>
            <span className="font-medium text-[#0B1F33]">We offer a free 7-Day Size Exchange!</span>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold uppercase tracking-wider bg-[#0B1F33] text-white rounded-lg hover:bg-[#132c48] transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
