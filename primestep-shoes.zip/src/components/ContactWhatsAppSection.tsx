import React, { useState } from 'react';
import { MessageCircle, Phone, Clock, MapPin, Send, HelpCircle, ChevronDown, CheckCircle2 } from 'lucide-react';
import { WHATSAPP_PHONE_RAW, WHATSAPP_PHONE_INTL, getSupportWhatsAppUrl, STORE_BLOG_URL } from '../utils/whatsapp';

export const ContactWhatsAppSection: React.FC = () => {
  const [customMsg, setCustomMsg] = useState('');
  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  const quickTopics = [
    { label: 'Check Size Availability', text: 'Hello PrimeStep Shoes, I want to check availability for my shoe size.' },
    { label: 'Delivery Time to My City', text: 'Hello PrimeStep Shoes, how many days will delivery take to my city?' },
    { label: 'Place Direct Order', text: 'Hello PrimeStep Shoes, I would like to place an order. Please guide me.' },
    { label: 'Exchange / Return Query', text: 'Hello PrimeStep Shoes, I need assistance regarding a size exchange for my recent order.' }
  ];

  const faqs = [
    {
      q: 'How does Cash on Delivery (COD) work?',
      a: 'You do not need to pay anything in advance. Once you place an order on our website or through WhatsApp, our team prepares and dispatches your pair via express courier. You hand the cash to the delivery rider only when the parcel arrives at your doorstep.'
    },
    {
      q: 'How long does shipping take across Pakistan?',
      a: 'Major metropolitan cities (Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad) typically receive deliveries within 2 to 3 business days. Other cities and surrounding regions receive parcels within 3 to 4 business days.'
    },
    {
      q: 'What is your size exchange policy?',
      a: 'We provide a 7-day hassle-free doorstep size exchange. If the shoe feels too tight or loose, simply notify our WhatsApp team at 03228426461 with your order number, and we will send the correct replacement size.'
    },
    {
      q: 'Are PrimeStep shoes made with genuine leather?',
      a: 'Yes, our formal dress shoes, oxfords, Chelsea boots, and loafers use premium full-grain and top-grain genuine leathers and rich suedes, lined with soft moisture-wicking sheepskin for breathability.'
    }
  ];

  const handleSendCustomMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMsg.trim()) return;
    const url = `https://wa.me/${WHATSAPP_PHONE_INTL}?text=${encodeURIComponent(customMsg.trim())}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleQuickTopic = (text: string) => {
    const url = `https://wa.me/${WHATSAPP_PHONE_INTL}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contact" className="py-16 sm:py-24 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
            <span className="text-xs uppercase tracking-widest font-bold text-[#D4AF37]">
              Customer Care & Ordering Desk
            </span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-[#0B1F33] tracking-tight">
            Order or Chat on WhatsApp
          </h2>
          <p className="text-sm text-slate-500 leading-relaxed">
            Need urgent assistance, live product photos, or instant order confirmation? Connect directly with our shoe specialists.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Direct WhatsApp Desk Card */}
          <div className="lg:col-span-6 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md">
                  <MessageCircle className="w-6 h-6 fill-white" />
                </div>
                <div>
                  <h3 className="font-serif-luxury text-lg font-bold text-[#0B1F33]">
                    PrimeStep WhatsApp Hotline
                  </h3>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>Live & Ready to Assist</span>
                  </div>
                </div>
              </div>

              <a
                href={`tel:${WHATSAPP_PHONE_RAW}`}
                className="text-xs font-semibold text-[#0B1F33] hover:text-[#D4AF37] px-3 py-1.5 bg-slate-100 rounded-lg flex items-center gap-1 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Directly</span>
              </a>
            </div>

            {/* Prominent Phone Highlight */}
            <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[11px] text-emerald-800 font-medium block">
                  Official Contact & WhatsApp Number:
                </span>
                <span className="font-mono text-2xl font-extrabold text-[#0B1F33]">
                  {WHATSAPP_PHONE_RAW}
                </span>
              </div>
              <a
                href={getSupportWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 shrink-0 cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Open WhatsApp</span>
              </a>
            </div>

            {/* Quick Inquiry Buttons */}
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-2.5">
                Quick 1-Click Questions:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {quickTopics.map((topic, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleQuickTopic(topic.text)}
                    className="p-2.5 text-left text-xs bg-slate-50 hover:bg-[#0B1F33] hover:text-white border border-slate-200 rounded-xl transition-all duration-200 flex items-center justify-between group cursor-pointer"
                  >
                    <span>{topic.label}</span>
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600 group-hover:text-white shrink-0 ml-1" />
                  </button>
                ))}
              </div>
            </div>

            {/* Type Message Form */}
            <form onSubmit={handleSendCustomMessage} className="space-y-3 pt-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
                Or Type Your Custom Message:
              </label>
              <div className="relative">
                <textarea
                  rows={3}
                  value={customMsg}
                  onChange={(e) => setCustomMsg(e.target.value)}
                  placeholder="Ask about size 43 availability, delivery to Islamabad, leather care instructions..."
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#0B1F33] resize-none"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-[#0B1F33] hover:bg-[#132c48] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Send to WhatsApp ({WHATSAPP_PHONE_RAW})</span>
              </button>
            </form>

            {/* Service hours & location note */}
            <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Mon – Sun: 9:00 AM – 11:00 PM</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Dispatched Nationwide from Lahore</span>
              </div>
            </div>
          </div>

          {/* Right Column: FAQ Accordion */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-2.5 mb-5 pb-4 border-b border-slate-100">
                <HelpCircle className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="font-serif-luxury text-lg font-bold text-[#0B1F33]">
                  Frequently Asked Questions
                </h3>
              </div>

              <div className="space-y-3">
                {faqs.map((faq, index) => {
                  const isOpen = activeFaq === index;
                  return (
                    <div
                      key={index}
                      className="border border-slate-200 rounded-2xl overflow-hidden transition-colors"
                    >
                      <button
                        type="button"
                        onClick={() => setActiveFaq(isOpen ? null : index)}
                        className="w-full p-4 text-left flex items-center justify-between gap-3 text-xs sm:text-sm font-semibold text-[#0B1F33] hover:bg-slate-50 transition-colors"
                      >
                        <span>{faq.q}</span>
                        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                      </button>

                      {isOpen && (
                        <div className="px-4 pb-4 pt-1 text-xs text-slate-600 leading-relaxed bg-slate-50/50 border-t border-slate-100">
                          {faq.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Trust Assurance Card */}
            <div className="p-6 rounded-3xl bg-[#0B1F33] text-white flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="space-y-1 text-center sm:text-left">
                <h4 className="font-bold text-sm text-white">Need Personal Sizing Recommendation?</h4>
                <p className="text-xs text-slate-300">
                  Send us a photo of your foot or previous shoes on WhatsApp for precise advice.
                </p>
              </div>
              <a
                href={getSupportWhatsAppUrl('Personal Foot Sizing Advice')}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 bg-[#D4AF37] hover:bg-[#b8952b] text-[#0B1F33] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shrink-0 cursor-pointer"
              >
                Ask Specialist
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
