import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Heart, 
  Search, 
  Menu, 
  X, 
  Phone, 
  MessageCircle, 
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { 
  WHATSAPP_PHONE_RAW, 
  STORE_BLOG_URL, 
  FACEBOOK_URL, 
  INSTAGRAM_URL, 
  PINTEREST_URL,
  getSupportWhatsAppUrl,
  formatPrice 
} from '../utils/whatsapp';

interface HeaderProps {
  cartCount: number;
  cartTotal: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onSelectCategory: (category: string) => void;
  activeCategory: string;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenSizeGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  cartTotal,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onSelectCategory,
  activeCategory,
  searchQuery,
  onSearchChange,
  onOpenSizeGuide,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const navLinks = [
    { label: 'Home', category: 'all', href: '#hero' },
    { label: 'Shop', category: 'all', href: '#shop' },
    { label: 'New Arrivals', category: 'new-arrivals', href: '#new-arrivals' },
    { label: "Men's Shoes", category: 'mens', href: '#mens' },
    { label: 'Casual Shoes', category: 'casual', href: '#casual' },
    { label: 'Running & Walking', category: 'running', href: '#running' },
    { label: 'Sale', category: 'sale', href: '#sale' },
    { label: 'Why PrimeStep', category: 'why', href: '#why-us' },
    { label: 'Reviews', category: 'reviews', href: '#reviews' },
    { label: 'Contact', category: 'contact', href: '#contact' },
  ];

  const handleNavClick = (link: typeof navLinks[0]) => {
    setMobileMenuOpen(false);
    if (['all', 'new-arrivals', 'mens', 'casual', 'running', 'sale'].includes(link.category)) {
      onSelectCategory(link.category);
    }
    const element = document.querySelector(link.href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white shadow-xs">
      {/* Top Notification & Utility Bar */}
      <div className="bg-[#0B1F33] text-white border-b border-[#132c48] text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex flex-col md:flex-row items-center justify-between gap-2">
          {/* Left: Announcement */}
          <div className="flex items-center gap-3 text-[11px] sm:text-xs text-slate-300">
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse" />
              <span>Cash on Delivery Nationwide · Free Shipping on Orders Over Rs. 5,000</span>
            </span>
          </div>

          {/* Right: Hotline, Blog & Social Links */}
          <div className="flex items-center gap-4 text-[11px]">
            {/* WhatsApp quick contact */}
            <a 
              href={getSupportWhatsAppUrl()} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-[#D4AF37] hover:underline font-semibold"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-[#D4AF37] text-[#0B1F33]" />
              <span>WhatsApp: {WHATSAPP_PHONE_RAW}</span>
            </a>

            <span className="hidden sm:inline text-slate-600">|</span>

            {/* Official Website link */}
            <a 
              href={STORE_BLOG_URL}
              target="_blank" 
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-1 text-slate-300 hover:text-white transition-colors"
            >
              <span>primestepshoes.blogspot.com</span>
              <ExternalLink className="w-3 h-3 text-[#D4AF37]" />
            </a>

            <span className="hidden md:inline text-slate-600">|</span>

            {/* Social icons */}
            <div className="flex items-center gap-2.5">
              <a 
                href={FACEBOOK_URL} 
                target="_blank" 
                rel="noopener noreferrer"
                title="Facebook" 
                className="text-slate-300 hover:text-[#D4AF37] transition-colors"
              >
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>

              <a 
                href={INSTAGRAM_URL} 
                target="_blank" 
                rel="noopener noreferrer"
                title="Instagram" 
                className="text-slate-300 hover:text-[#D4AF37] transition-colors"
              >
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>

              <a 
                href={PINTEREST_URL} 
                target="_blank" 
                rel="noopener noreferrer"
                title="Pinterest" 
                className="text-slate-300 hover:text-[#D4AF37] transition-colors"
              >
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345-.09.375-.291 1.199-.332 1.357-.053.211-.174.256-.402.155-1.499-.696-2.435-2.88-2.435-4.634 0-3.774 2.743-7.239 7.904-7.239 4.151 0 7.378 2.958 7.378 6.91 0 4.123-2.599 7.441-6.207 7.441-1.212 0-2.352-.63-2.743-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146 1.124.347 2.317.535 3.554.535 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-20 gap-4">
          {/* Brand Logo */}
          <a href="#hero" className="flex items-center gap-3 group shrink-0">
            {/* Elegant Monogram Crest */}
            <div className="w-11 h-11 rounded-xl bg-[#0B1F33] flex items-center justify-center text-[#D4AF37] shadow-md group-hover:scale-105 transition-transform border border-[#D4AF37]/30">
              <span className="font-serif-luxury font-bold text-xl tracking-tight">PS</span>
            </div>
            <div className="flex flex-col">
              <span className="font-serif-luxury text-xl sm:text-2xl font-bold tracking-tight text-[#0B1F33] leading-none">
                PrimeStep
              </span>
              <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-[0.22em] text-[#D4AF37] mt-0.5">
                SHOES · EST. 2026
              </span>
            </div>
          </a>

          {/* Desktop Search Input */}
          <div className="hidden lg:flex items-center relative flex-1 max-w-xs xl:max-w-sm mx-4">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
            <input
              type="text"
              placeholder="Search dress shoes, sneakers, boots..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-xs bg-slate-100 hover:bg-slate-50 focus:bg-white border border-transparent focus:border-[#0B1F33] rounded-full focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button 
                onClick={() => onSearchChange('')} 
                className="absolute right-3 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Action Affordances: Wishlist, Cart & Mobile Trigger */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Sizing Help Link */}
            <button
              onClick={onOpenSizeGuide}
              className="hidden md:inline-flex text-xs font-semibold text-slate-600 hover:text-[#0B1F33] px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Size Guide
            </button>

            {/* Mobile Search Toggle */}
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Toggle search"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist Button */}
            <button
              onClick={onOpenWishlist}
              className="relative p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="View wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center font-mono">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Cart Button */}
            <button
              onClick={onOpenCart}
              className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-[#0B1F33] text-white hover:bg-[#132c48] transition-colors shadow-xs cursor-pointer"
              aria-label="View shopping bag"
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 w-4 h-4 bg-[#D4AF37] text-[#0B1F33] text-[10px] font-bold rounded-full flex items-center justify-center font-mono">
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-[10px] text-slate-300 uppercase leading-none">Bag</span>
                <span className="text-xs font-bold font-mono text-[#D4AF37] leading-tight">
                  {formatPrice(cartTotal)}
                </span>
              </div>
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Open navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar Expansion */}
        {isSearchOpen && (
          <div className="lg:hidden pb-3 pt-1">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search shoes by name, type, color..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-9 pr-8 py-2 text-xs bg-slate-100 border border-slate-200 rounded-xl focus:outline-none focus:border-[#0B1F33]"
                autoFocus
              />
              {searchQuery && (
                <button 
                  onClick={() => onSearchChange('')} 
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        )}

        {/* Desktop Secondary Clean Links Strip */}
        <nav className="hidden md:flex items-center justify-between border-t border-slate-100 py-2.5 text-xs font-semibold tracking-wide uppercase text-slate-700">
          <div className="flex items-center gap-6 xl:gap-8">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => handleNavClick(link)}
                className={`relative py-1 transition-colors hover:text-[#0B1F33] cursor-pointer ${
                  activeCategory === link.category
                    ? 'text-[#0B1F33] font-bold after:absolute after:bottom-0 after:left-0 after:w-full after:h-0.5 after:bg-[#D4AF37]'
                    : 'text-slate-600'
                }`}
              >
                {link.label === 'Sale' ? (
                  <span className="text-red-600 font-bold flex items-center gap-1">
                    {link.label}
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping" />
                  </span>
                ) : (
                  link.label
                )}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4 text-slate-500 font-normal normal-case text-xs">
            <span className="flex items-center gap-1 text-[#0B1F33] font-medium">
              <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Call / WhatsApp: <strong>{WHATSAPP_PHONE_RAW}</strong></span>
            </span>
          </div>
        </nav>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white shadow-xl animate-fadeIn">
          <div className="px-4 py-4 space-y-2">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => handleNavClick(link)}
                className={`w-full text-left px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors flex items-center justify-between ${
                  activeCategory === link.category
                    ? 'bg-[#0B1F33] text-white'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>{link.label}</span>
                {link.label === 'Sale' && (
                  <span className="text-[10px] bg-red-600 text-white px-2 py-0.5 rounded-full font-bold">
                    UP TO 30% OFF
                  </span>
                )}
              </button>
            ))}

            <div className="pt-3 border-t border-slate-200 space-y-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenSizeGuide();
                }}
                className="w-full text-left px-3 py-2 text-xs font-semibold text-slate-600 hover:text-[#0B1F33]"
              >
                View Footwear Sizing Chart
              </button>

              <a
                href={getSupportWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 text-white text-xs font-semibold rounded-xl shadow-xs"
              >
                <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                <span>Order via WhatsApp ({WHATSAPP_PHONE_RAW})</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
