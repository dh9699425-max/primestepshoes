import React from 'react';
import { Star, CheckCircle, Quote, ThumbsUp } from 'lucide-react';
import { REVIEWS } from '../data/reviews';

export const ReviewsSection: React.FC = () => {
  return (
    <section id="reviews" className="py-16 sm:py-24 bg-slate-50/70 border-t border-slate-200/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 sm:mb-16">
          <div className="max-w-2xl space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
              <span className="text-xs uppercase tracking-widest font-bold text-[#D4AF37]">
                Customer Testimonials
              </span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-[#0B1F33] tracking-tight">
              What Our Walkers & Gentlemen Say
            </h2>
            <p className="text-sm text-slate-500 leading-relaxed">
              Read real, unbiased impressions from footwear enthusiasts across Pakistan who stepped up their style with PrimeStep Shoes.
            </p>
          </div>

          {/* Rating Summary Card */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4 shrink-0">
            <div className="text-center">
              <span className="font-mono text-3xl font-extrabold text-[#0B1F33] block leading-none">
                4.9
              </span>
              <div className="flex items-center gap-0.5 justify-center mt-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
                ))}
              </div>
            </div>
            <div className="h-10 w-px bg-slate-200" />
            <div className="text-xs text-slate-600">
              <span className="font-bold text-[#0B1F33] block">Over 850+ Happy Buyers</span>
              <span className="text-slate-400">98% Positive Feedback</span>
            </div>
          </div>
        </div>

        {/* Review Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {REVIEWS.map((review) => (
            <div
              key={review.id}
              className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                {/* Top: Stars & Date */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#D4AF37] text-[#D4AF37]" />
                    ))}
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">{review.date}</span>
                </div>

                {/* Purchased product tag */}
                <div className="mb-3 text-[11px] text-slate-500 font-medium">
                  Purchased: <strong className="text-[#0B1F33]">{review.productName}</strong>
                </div>

                {/* Quote */}
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed italic">
                  "{review.comment}"
                </p>
              </div>

              {/* Author & Verification badge */}
              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-xs sm:text-sm text-[#0B1F33]">
                    {review.name}
                  </h4>
                  <span className="text-[11px] text-slate-400">{review.city}</span>
                </div>

                {review.verified && (
                  <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                    <CheckCircle className="w-3 h-3 text-emerald-600" />
                    <span>Verified Buyer</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
