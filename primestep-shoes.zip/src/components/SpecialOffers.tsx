import React, { useState, useEffect } from 'react';
import { Tag, Copy, Check, Clock, Sparkles, MessageCircle } from 'lucide-react';
import { Product, ProductColor } from '../types';
import { ProductCard } from './ProductCard';
import { WHATSAPP_PHONE_RAW, getSupportWhatsAppUrl } from '../utils/whatsapp';

interface SpecialOffersProps {
  products: Product[];
  onAddToCart: (product: Product, size: number, color: ProductColor) => void;
  onBuyNow: (product: Product, size: number, color: ProductColor) => void;
  onQuickView: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: string[];
}

export const SpecialOffers: React.FC<SpecialOffersProps> = ({
  products,
  onAddToCart,
  onBuyNow,
  onQuickView,
  onToggleWishlist,
  wishlistIds,
}) => {
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState({
    hours: 18,
    minutes: 42,
    seconds: 15,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 24, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCopyCode = () => {
    navigator.clipboard.writeText('STEP10');
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const saleProducts = products.filter((p) => p.isSale || (p.salePrice && p.salePrice < p.price));

  return (
    <section id="sale" className="py-16 sm:py-20 bg-gradient-to-b from-[#0B1F33] via-[#0E2842] to-[#0B1F33] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Sale Banner & Countdown */}
        <div className="bg-gradient-to-r from-[#132c48] via-[#1a385c] to-[#132c48] border border-[#D4AF37]/30 rounded-3xl p-6 sm:p-10 mb-12 shadow-2xl relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="space-y-3 text-center lg:text-left max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/40 text-red-300 text-xs font-bold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-red-400" />
                <span>Limited Time Promotion</span>
              </div>
              <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-white tracking-tight">
                PrimeStep Clearance & Seasonal Sale
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                Enjoy up to <strong>30% OFF</strong> select handcrafted oxfords, luxury boots, and cushioned performance runners. Apply the promo voucher at checkout or mention it on WhatsApp!
              </p>
            </div>

            {/* Countdown Box & Promo Voucher */}
            <div className="flex flex-col sm:flex-row items-center gap-6 w-full lg:w-auto">
              {/* Countdown clock */}
              <div className="flex items-center gap-2 text-center">
                <div className="bg-[#0B1F33] border border-white/10 rounded-xl px-3 py-2.5 min-w-[60px]">
                  <span className="block font-mono text-xl sm:text-2xl font-bold text-[#D4AF37]">
                    {String(timeLeft.hours).padStart(2, '0')}
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase">Hours</span>
                </div>
                <span className="text-[#D4AF37] font-bold text-lg">:</span>
                <div className="bg-[#0B1F33] border border-white/10 rounded-xl px-3 py-2.5 min-w-[60px]">
                  <span className="block font-mono text-xl sm:text-2xl font-bold text-[#D4AF37]">
                    {String(timeLeft.minutes).padStart(2, '0')}
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase">Mins</span>
                </div>
                <span className="text-[#D4AF37] font-bold text-lg">:</span>
                <div className="bg-[#0B1F33] border border-white/10 rounded-xl px-3 py-2.5 min-w-[60px]">
                  <span className="block font-mono text-xl sm:text-2xl font-bold text-[#D4AF37]">
                    {String(timeLeft.seconds).padStart(2, '0')}
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase">Secs</span>
                </div>
              </div>

              {/* Promo code badge */}
              <div className="bg-white/10 border border-white/20 rounded-2xl p-3 flex items-center justify-between gap-3 w-full sm:w-auto">
                <div className="text-left">
                  <span className="block text-[10px] uppercase tracking-wider text-slate-300">
                    Voucher Code
                  </span>
                  <span className="font-mono font-bold text-base text-[#D4AF37] tracking-wider">
                    STEP10
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="px-3 py-1.5 rounded-lg bg-[#D4AF37] hover:bg-[#b8952b] text-[#0B1F33] text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Sale Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
          {saleProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
              onBuyNow={onBuyNow}
              onQuickView={onQuickView}
              onToggleWishlist={onToggleWishlist}
              isWishlisted={wishlistIds.includes(product.id)}
            />
          ))}
        </div>

        {/* WhatsApp Bargain Banner */}
        <div className="mt-12 p-6 rounded-2xl bg-white/5 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <h4 className="font-semibold text-white text-sm">Looking for Corporate or Bulk Shoe Orders?</h4>
            <p className="text-xs text-slate-300">
              Get special volume discounts on formal office and institutional footwear via WhatsApp hotline.
            </p>
          </div>
          <a
            href={getSupportWhatsAppUrl('Bulk / Corporate Footwear Inquiry')}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors shrink-0"
          >
            <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
            <span>Chat on WhatsApp ({WHATSAPP_PHONE_RAW})</span>
          </a>
        </div>
      </div>
    </section>
  );
};
