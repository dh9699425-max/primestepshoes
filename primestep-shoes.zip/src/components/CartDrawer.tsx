import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, MessageCircle, ArrowRight, ShieldCheck, Tag } from 'lucide-react';
import { CartItem } from '../types';
import { formatPrice, getCartWhatsAppUrl, WHATSAPP_PHONE_RAW } from '../utils/whatsapp';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, delta: number) => void;
  onRemoveItem: (index: number) => void;
  onOpenCheckoutModal: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onOpenCheckoutModal,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [couponMessage, setCouponMessage] = useState<string>('');

  if (!isOpen) return null;

  const rawSubtotal = items.reduce((sum, item) => {
    const price = item.product.salePrice || item.product.price;
    return sum + price * item.quantity;
  }, 0);

  const discountAmount = Math.round((rawSubtotal * discountPercent) / 100);
  const discountedSubtotal = rawSubtotal - discountAmount;
  // Free delivery threshold: Rs. 5,000
  const freeShippingThreshold = 5000;
  const shippingFee = rawSubtotal === 0 || rawSubtotal >= freeShippingThreshold ? 0 : 250;
  const finalTotal = discountedSubtotal + shippingFee;

  const progressToFreeShipping = Math.min(100, Math.round((rawSubtotal / freeShippingThreshold) * 100));

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const code = couponCode.trim().toUpperCase();
    if (code === 'STEP10') {
      setDiscountPercent(10);
      setCouponMessage('Coupon applied! 10% discount added.');
    } else if (code === 'PRIME15' && rawSubtotal >= 8000) {
      setDiscountPercent(15);
      setCouponMessage('VIP coupon applied! 15% discount added.');
    } else {
      setDiscountPercent(0);
      setCouponMessage('Invalid code. Try "STEP10" for 10% off.');
    }
  };

  const handleWhatsAppCheckout = () => {
    const url = getCartWhatsAppUrl(items, rawSubtotal, shippingFee, finalTotal);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between border-l border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-[#0B1F33] text-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-serif-luxury text-lg tracking-wide">Your Shopping Bag</h3>
            <span className="text-xs bg-[#D4AF37] text-[#0B1F33] font-bold px-2 py-0.5 rounded-full font-mono">
              {items.reduce((acc, it) => acc + it.quantity, 0)}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Meter */}
        <div className="px-6 py-3 bg-amber-50/70 border-b border-amber-200/60 text-xs">
          {rawSubtotal >= freeShippingThreshold ? (
            <p className="text-emerald-800 font-semibold flex items-center gap-1.5">
              <span>🎉 Congratulations! You have qualified for</span>
              <strong className="underline">FREE Express Delivery</strong>!
            </p>
          ) : (
            <div>
              <p className="text-slate-700">
                Add <strong>{formatPrice(freeShippingThreshold - rawSubtotal)}</strong> more to get{' '}
                <strong className="text-[#0B1F33]">Free Delivery</strong>!
              </p>
              <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
                <div 
                  className="bg-[#D4AF37] h-full transition-all duration-300"
                  style={{ width: `${progressToFreeShipping}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12 text-slate-400">
              <ShoppingBag className="w-16 h-16 stroke-[1.2] mb-3 text-slate-300" />
              <h4 className="text-base font-semibold text-slate-700">Your bag is empty</h4>
              <p className="text-xs text-slate-500 max-w-xs mt-1">
                Explore our premium men's formal, casual, or running collections and step into ultimate style.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-6 px-6 py-2.5 bg-[#0B1F33] text-white text-xs font-semibold uppercase tracking-wider rounded-xl hover:bg-[#132c48] transition-colors"
              >
                Start Shopping
              </button>
            </div>
          ) : (
            items.map((item, index) => {
              const itemUnitPrice = item.product.salePrice || item.product.price;
              return (
                <div 
                  key={`${item.product.id}-${item.selectedSize}-${item.selectedColor.name}-${index}`}
                  className="flex gap-4 p-3 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-20 h-20 object-cover rounded-lg shrink-0 border border-slate-200"
                  />
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="text-xs sm:text-sm font-semibold text-[#0B1F33] truncate">
                          {item.product.name}
                        </h4>
                        <button
                          type="button"
                          onClick={() => onRemoveItem(index)}
                          className="text-slate-400 hover:text-red-600 p-1 transition-colors"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500">
                        <span className="bg-slate-200 px-1.5 py-0.5 rounded text-slate-700 font-mono font-medium">
                          EU {item.selectedSize}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <span 
                            className="w-2.5 h-2.5 rounded-full border border-black/20" 
                            style={{ backgroundColor: item.selectedColor.hex }}
                          />
                          {item.selectedColor.name}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-1 border-t border-slate-200/60">
                      <div className="flex items-center border border-slate-300 rounded-md bg-white">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(index, -1)}
                          className="px-2 py-0.5 text-xs text-slate-600 hover:bg-slate-100"
                        >
                          -
                        </button>
                        <span className="px-2.5 py-0.5 text-xs font-mono font-bold text-slate-800">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(index, 1)}
                          className="px-2 py-0.5 text-xs text-slate-600 hover:bg-slate-100"
                        >
                          +
                        </button>
                      </div>
                      <span className="text-xs sm:text-sm font-bold font-mono text-[#0B1F33]">
                        {formatPrice(itemUnitPrice * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer & Checkout Module */}
        {items.length > 0 && (
          <div className="p-6 border-t border-slate-200 bg-white space-y-4">
            {/* Promo Code Form */}
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Promo Code (Try STEP10)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs uppercase font-mono tracking-wider bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#0B1F33]"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-[#0B1F33] rounded-xl transition-colors"
              >
                Apply
              </button>
            </form>
            {couponMessage && (
              <p className={`text-[11px] ${discountPercent > 0 ? 'text-emerald-700' : 'text-amber-700'}`}>
                {couponMessage}
              </p>
            )}

            {/* Calculations */}
            <div className="space-y-1.5 text-xs text-slate-600 border-t border-slate-100 pt-3">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span className="font-mono text-slate-800 font-medium">{formatPrice(rawSubtotal)}</span>
              </div>
              {discountPercent > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Discount ({discountPercent}%):</span>
                  <span className="font-mono">-{formatPrice(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Shipping:</span>
                <span className="font-mono text-slate-800">
                  {shippingFee === 0 ? <span className="text-emerald-700 font-semibold">FREE</span> : formatPrice(shippingFee)}
                </span>
              </div>
              <div className="flex justify-between text-base font-bold text-[#0B1F33] pt-2 border-t border-slate-200">
                <span>Total Payable:</span>
                <span className="font-mono text-lg">{formatPrice(finalTotal)}</span>
              </div>
            </div>

            {/* Checkout Action Options */}
            <div className="space-y-2 pt-1">
              {/* WhatsApp Checkout */}
              <button
                type="button"
                onClick={handleWhatsAppCheckout}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                <span>Order Bag on WhatsApp ({WHATSAPP_PHONE_RAW})</span>
              </button>

              {/* Standard COD Checkout */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenCheckoutModal();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-xs sm:text-sm font-semibold text-white bg-[#0B1F33] hover:bg-[#132c48] rounded-xl shadow-md transition-all cursor-pointer"
              >
                <span>Cash on Delivery Checkout</span>
                <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
              </button>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Safe & Secure Checkout · Pay on Delivery</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
