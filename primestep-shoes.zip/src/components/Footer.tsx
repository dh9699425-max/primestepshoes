import React, { useState } from 'react';
import { 
  Phone, 
  MessageCircle, 
  ExternalLink, 
  Mail, 
  ArrowUp, 
  ShieldCheck, 
  Truck, 
  RotateCcw,
  Check
} from 'lucide-react';
import { 
  WHATSAPP_PHONE_RAW, 
  STORE_BLOG_URL, 
  FACEBOOK_URL, 
  INSTAGRAM_URL, 
  PINTEREST_URL,
  getSupportWhatsAppUrl 
} from '../utils/whatsapp';

interface FooterProps {
  onSelectCategory: (category: string) => void;
  onOpenSizeGuide: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory, onOpenSizeGuide }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setSubscribed(true);
    setNewsletterEmail('');
    setTimeout(() => setSubscribed(false), 4000);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0B1F33] text-white border-t border-[#132c48]">
      {/* Top Value Banner */}
      <div className="border-b border-[#132c48] py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#D4AF37] shrink-0">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Nationwide Fast Delivery</h4>
                <p className="text-xs text-slate-400 mt-0.5">Dispatched within 24–48 hours across Pakistan</p>
              </div>
            </div>

            <div className="flex items-center justify-center md:justify-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#D4AF37] shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Cash on Delivery (COD)</h4>
                <p className="text-xs text-slate-400 mt-0.5">Pay safely upon delivery at your doorstep</p>
              </div>
            </div>

            <div className="flex items-center justify-center md:justify-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#D4AF37] shrink-0">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">7-Day Free Size Exchange</h4>
                <p className="text-xs text-slate-400 mt-0.5">Convenient doorstep fit replacement</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Brand Info & Mission */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white text-[#0B1F33] flex items-center justify-center shadow-md">
                <span className="font-serif-luxury font-bold text-lg">PS</span>
              </div>
              <div className="flex flex-col">
                <span className="font-serif-luxury text-xl font-bold tracking-tight text-white leading-none">
                  PrimeStep Shoes
                </span>
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D4AF37] mt-1">
                  Step Into Style
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed max-w-sm">
              PrimeStep Shoes delivers high-caliber footwear engineering, from hand-finished Italian calfskin formal shoes to ultra-light cushioned daily runners.
            </p>

            {/* Direct Contact info */}
            <div className="space-y-2 pt-2 text-xs">
              <a 
                href={getSupportWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-300 hover:text-[#D4AF37] transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>WhatsApp / Contact: <strong className="text-white font-mono">{WHATSAPP_PHONE_RAW}</strong></span>
              </a>

              <a 
                href={`tel:${WHATSAPP_PHONE_RAW}`}
                className="flex items-center gap-2 text-slate-300 hover:text-[#D4AF37] transition-colors"
              >
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Phone: <strong className="text-white font-mono">{WHATSAPP_PHONE_RAW}</strong></span>
              </a>

              <a 
                href={STORE_BLOG_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors"
              >
                <ExternalLink className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="underline underline-offset-2">https://primestepshoes.blogspot.com/</span>
              </a>
            </div>
          </div>

          {/* Footwear Collections */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-serif-luxury text-sm font-bold text-white tracking-wider uppercase">
              Collections
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button 
                  onClick={() => onSelectCategory('mens')} 
                  className="hover:text-white transition-colors text-left"
                >
                  Men's Formal Shoes
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onSelectCategory('mens')} 
                  className="hover:text-white transition-colors text-left"
                >
                  Italian Leather Oxfords
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onSelectCategory('casual')} 
                  className="hover:text-white transition-colors text-left"
                >
                  Casual Leather Sneakers
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onSelectCategory('casual')} 
                  className="hover:text-white transition-colors text-left"
                >
                  Handcrafted Loafers
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onSelectCategory('running')} 
                  className="hover:text-white transition-colors text-left"
                >
                  Running & Walking Shoes
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onSelectCategory('sale')} 
                  className="text-red-400 hover:text-red-300 transition-colors text-left font-semibold"
                >
                  Seasonal Sale (Up to 30% Off)
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Help & Policy Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-serif-luxury text-sm font-bold text-white tracking-wider uppercase">
              Customer Care
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button 
                  onClick={onOpenSizeGuide} 
                  className="hover:text-white transition-colors text-left"
                >
                  Footwear Size Guide
                </button>
              </li>
              <li>
                <a href="#why-us" className="hover:text-white transition-colors block">
                  7-Day Size Exchange
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-white transition-colors block">
                  Cash on Delivery Info
                </a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-white transition-colors block">
                  Verified Customer Reviews
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-white transition-colors block">
                  Track My Order
                </a>
              </li>
              <li>
                <a 
                  href={getSupportWhatsAppUrl('Order Support Help')} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:text-emerald-300 transition-colors block"
                >
                  Instant WhatsApp Help
                </a>
              </li>
            </ul>
          </div>

          {/* Social Media & Newsletter */}
          <div className="lg:col-span-4 space-y-4">
            <h4 className="font-serif-luxury text-sm font-bold text-white tracking-wider uppercase">
              Social Links & Newsletter
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Subscribe for private release drops, sizing guidance, and limited seasonal coupon vouchers.
            </p>

            <form onSubmit={handleSubscribe} className="flex gap-2">
              <div className="relative flex-1">
                <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  placeholder="Enter your email address"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-white/10 border border-white/15 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-[#D4AF37] hover:bg-[#b8952b] text-[#0B1F33] text-xs font-bold uppercase rounded-xl transition-colors cursor-pointer shrink-0"
              >
                Join
              </button>
            </form>

            {subscribed && (
              <p className="text-xs text-emerald-400 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" />
                <span>Thank you for subscribing to PrimeStep Shoes!</span>
              </p>
            )}

            {/* Social Icons Strip with required links */}
            <div className="pt-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Official Channels:
              </span>
              <div className="flex items-center gap-3">
                {/* Facebook */}
                <a
                  href={FACEBOOK_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="PrimeStep on Facebook"
                  className="w-9 h-9 rounded-xl bg-white/10 hover:bg-[#1877F2] text-white flex items-center justify-center transition-colors"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                </a>

                {/* Instagram */}
                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="PrimeStep on Instagram"
                  className="w-9 h-9 rounded-xl bg-white/10 hover:bg-gradient-to-tr hover:from-amber-500 hover:via-pink-500 hover:to-purple-600 text-white flex items-center justify-center transition-colors"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                </a>

                {/* Pinterest */}
                <a
                  href={PINTEREST_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="PrimeStep on Pinterest"
                  className="w-9 h-9 rounded-xl bg-white/10 hover:bg-[#E60023] text-white flex items-center justify-center transition-colors"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345-.09.375-.291 1.199-.332 1.357-.053.211-.174.256-.402.155-1.499-.696-2.435-2.88-2.435-4.634 0-3.774 2.743-7.239 7.904-7.239 4.151 0 7.378 2.958 7.378 6.91 0 4.123-2.599 7.441-6.207 7.441-1.212 0-2.352-.63-2.743-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146 1.124.347 2.317.535 3.554.535 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/>
                  </svg>
                </a>

                {/* WhatsApp */}
                <a
                  href={getSupportWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="PrimeStep on WhatsApp"
                  className="w-9 h-9 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center transition-colors"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Back to Top Bar */}
        <div className="mt-14 pt-8 border-t border-[#132c48] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 text-center sm:text-left">
            <span className="font-semibold text-slate-200">
              PrimeStep Shoes — Step Into Style
            </span>
            <span className="hidden sm:inline text-slate-600">·</span>
            <span>
              Copyright © 2026 PrimeStep Shoes. All Rights Reserved.
            </span>
          </div>

          <div className="flex items-center gap-4">
            <a 
              href={STORE_BLOG_URL}
              target="_blank" 
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-[#D4AF37] transition-colors"
            >
              Official Blog
            </a>

            <button
              onClick={scrollToTop}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
