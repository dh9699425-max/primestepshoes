import React from 'react';
import { ArrowRight, MessageCircle, ShieldCheck, Truck, RotateCcw, Award, Sparkles } from 'lucide-react';
import { WHATSAPP_PHONE_RAW, getSupportWhatsAppUrl } from '../utils/whatsapp';

interface HeroProps {
  onExploreShop: () => void;
  onExploreNewArrivals: () => void;
  onExploreSale: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreShop,
  onExploreNewArrivals,
  onExploreSale,
}) => {
  return (
    <section id="hero" className="relative bg-[#0B1F33] text-white overflow-hidden">
      {/* Subtle geometric luxury background grid */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#D4AF37_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />
      
      {/* Ambient gradient glow */}
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-20 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Editorial Headline & Actions */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-center lg:text-left">
            {/* Subtle Brand Kicker */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-slate-300 backdrop-blur-xs">
              <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
              <span className="font-semibold tracking-wider uppercase text-[#D4AF37] text-[11px]">
                PrimeStep Shoes · 2026 Collection
              </span>
              <span className="text-slate-500">|</span>
              <span className="text-slate-300">Step Into Style</span>
            </div>

            {/* Main Headline */}
            <div className="space-y-3">
              <h1 className="font-serif-luxury text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.12]">
                Elegance You Wear. <br className="hidden sm:inline" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-[#D4AF37]">
                  Comfort In Every Step.
                </span>
              </h1>
              <p className="text-sm sm:text-base lg:text-lg text-slate-300 font-light max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                Discover mastercrafted Italian calfskin formal shoes, buttery suede loafers, and nitrogen-cushioned running trainers designed for the modern lifestyle.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
              <button
                type="button"
                onClick={onExploreShop}
                className="w-full sm:w-auto px-8 py-3.5 bg-[#D4AF37] hover:bg-[#b8952b] text-[#0B1F33] font-bold text-xs sm:text-sm uppercase tracking-wider rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Explore Collection</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href={getSupportWhatsAppUrl('Direct Inquiries & Custom Ordering')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm rounded-xl transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2.5 cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                <span>Order on WhatsApp ({WHATSAPP_PHONE_RAW})</span>
              </a>

              <button
                type="button"
                onClick={onExploreSale}
                className="w-full sm:w-auto px-5 py-3.5 bg-white/5 hover:bg-white/10 text-white border border-white/15 font-semibold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Season Sale</span>
              </button>
            </div>

            {/* Key Micro-Stats */}
            <div className="pt-4 border-t border-white/10 grid grid-cols-3 gap-4 text-center lg:text-left">
              <div>
                <span className="block font-mono text-xl sm:text-2xl font-bold text-white">100%</span>
                <span className="text-[11px] text-slate-400">Genuine Materials</span>
              </div>
              <div>
                <span className="block font-mono text-xl sm:text-2xl font-bold text-[#D4AF37]">4.9 / 5</span>
                <span className="text-[11px] text-slate-400">Customer Satisfaction</span>
              </div>
              <div>
                <span className="block font-mono text-xl sm:text-2xl font-bold text-white">48 Hours</span>
                <span className="text-[11px] text-slate-400">Express Delivery</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Outer decorative card frame */}
              <div className="relative aspect-4/5 rounded-3xl overflow-hidden border border-white/20 shadow-2xl bg-gradient-to-b from-slate-800 to-slate-900 group">
                <img
                  src="https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=1000&q=85"
                  alt="PrimeStep Sovereign Italian Leather Oxford"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                />

                {/* Scrim Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1F33] via-transparent to-transparent opacity-80" />

                {/* Floating Product Highlight Tag */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-white/95 backdrop-blur-md text-[#0B1F33] shadow-xl border border-white">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span className="uppercase font-bold tracking-wider text-[#D4AF37] text-[10px]">
                      Flagship Model
                    </span>
                    <span className="font-mono font-semibold text-emerald-700">Cash on Delivery</span>
                  </div>
                  <h3 className="font-serif-luxury font-bold text-base text-[#0B1F33]">
                    Sovereign Italian Oxford
                  </h3>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100">
                    <div className="flex items-baseline gap-2">
                      <span className="font-mono font-bold text-base text-[#0B1F33]">Rs. 6,999</span>
                      <span className="font-mono text-xs text-slate-400 line-through">Rs. 8,999</span>
                    </div>
                    <button
                      type="button"
                      onClick={onExploreNewArrivals}
                      className="text-xs font-bold text-[#0B1F33] hover:text-[#D4AF37] flex items-center gap-1 transition-colors"
                    >
                      <span>View Details</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Floating Quality Badge */}
              <div className="absolute -top-4 -left-4 p-3.5 bg-white text-[#0B1F33] rounded-2xl shadow-xl flex items-center gap-3 border border-slate-100 hidden sm:flex">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-[#D4AF37] flex items-center justify-center">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <span className="block text-xs font-bold leading-tight">Handcrafted Finish</span>
                  <span className="text-[10px] text-slate-500">Premium Grade Leather</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Trust Indicators Strip */}
        <div className="mt-12 lg:mt-16 pt-8 border-t border-white/10 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3 text-slate-200">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#D4AF37] shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white">Free Express Shipping</h4>
              <p className="text-[11px] text-slate-400">On all orders above Rs. 5,000</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-slate-200">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#D4AF37] shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white">Cash on Delivery (COD)</h4>
              <p className="text-[11px] text-slate-400">Pay safely upon doorstep arrival</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-slate-200">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#D4AF37] shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white">7-Day Size Exchange</h4>
              <p className="text-[11px] text-slate-400">Hassle-free fit guarantee</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-slate-200">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-emerald-400 shrink-0">
              <MessageCircle className="w-5 h-5 fill-emerald-400 text-[#0B1F33]" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white">WhatsApp Orders 24/7</h4>
              <p className="text-[11px] text-slate-400">Instant answers at {WHATSAPP_PHONE_RAW}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
